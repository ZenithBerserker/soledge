import jwt from 'jsonwebtoken'

const SECRET = process.env.NEXTAUTH_SECRET ?? 'dev-secret-change-me'

export interface TokenPayload {
  sub: string
  tier?: 'FREE' | 'PRO' | 'ELITE'
  iat: number
  exp: number
}

export async function verifyToken(token: string): Promise<TokenPayload> {
  return new Promise((resolve, reject) => {
    jwt.verify(token, SECRET, (err, decoded) => {
      if (err) return reject(err)
      resolve(decoded as TokenPayload)
    })
  })
}

export function signToken(payload: Omit<TokenPayload, 'iat' | 'exp'>): string {
  return jwt.sign(payload, SECRET, { expiresIn: '7d' })
}
