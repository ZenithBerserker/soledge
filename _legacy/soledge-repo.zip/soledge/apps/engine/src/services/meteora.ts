// apps/engine/src/services/meteora.ts
// Meteora DLMM pool arbitrage detector
// Monitors pools for extreme price imbalances and multi-hop arb opportunities

import { Connection, PublicKey, Transaction, TransactionInstruction } from '@solana/web3.js'
import { connection } from './helius'
import { broadcast } from '../websocket'
import { prisma } from './db'

// Meteora DLMM program
const METEORA_DLMM = new PublicKey('LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo')
// Jupiter v6 — for route simulation
const JUPITER_QUOTE_API = 'https://quote-api.jup.ag/v6'

// Blacklisted known-rug tokens
const BLACKLIST = new Set<string>()

export interface ArbOpportunity {
  tokenPair: string
  mintX: string
  mintY: string
  poolAddress: string
  estimatedInputUsdc: number
  projectedReturnX: number   // multiplier
  projectedReturnUsd: number
  routeSteps: string[]
  recommendedJitoTipSol: number
  confidenceLevel: 'HIGH' | 'MEDIUM' | 'LOW'
  detectedAt: string
}

// ─── Pool state cache ─────────────────────────────────────────────────────────

interface PoolState {
  address: string
  mintX: string
  mintY: string
  reserveX: bigint
  reserveY: bigint
  priceX: number   // Y per X
  liqUsd: number
  lastUpdated: number
}

const poolCache = new Map<string, PoolState>()

// ─── Subscribe to Meteora DLMM pools ─────────────────────────────────────────

export async function subscribeMeteoraLaunches(
  onOpportunity: (opp: ArbOpportunity) => void
): Promise<number> {
  const subId = connection.onProgramAccountChange(
    METEORA_DLMM,
    async (accountInfo, context) => {
      try {
        const data = accountInfo.accountInfo.data
        if (data.length < 200) return

        const poolAddr = accountInfo.accountId.toBase58()
        const { mintX, mintY, reserveX, reserveY } = parseDlmmPoolState(data)

        if (!mintX || !mintY) return
        if (BLACKLIST.has(mintX) || BLACKLIST.has(mintY)) return

        // Calculate implied price
        const priceX = reserveX > 0n ? Number(reserveY) / Number(reserveX) : 0
        const liqUsd = await estimateLiqUsd(mintX, mintY, reserveX, reserveY)

        const prev = poolCache.get(poolAddr)
        poolCache.set(poolAddr, {
          address: poolAddr, mintX, mintY, reserveX, reserveY,
          priceX, liqUsd, lastUpdated: Date.now()
        })

        if (!prev) {
          // New pool — check for extreme initial imbalance
          await detectNewPoolImbalance(poolAddr, mintX, mintY, liqUsd, priceX, onOpportunity)
          return
        }

        // Check for sudden price divergence (10x+ imbalance after large buy/sell)
        const priceRatio = priceX > 0 && prev.priceX > 0 ? priceX / prev.priceX : 1
        if (priceRatio >= 10 || priceRatio <= 0.1) {
          await detectPriceImbalance(
            poolAddr, mintX, mintY, liqUsd, priceX, prev.priceX, priceRatio, onOpportunity
          )
        }
      } catch { /* malformed data */ }
    },
    'confirmed'
  )
  return subId
}

// ─── Parse DLMM pool state ────────────────────────────────────────────────────

function parseDlmmPoolState(data: Buffer): {
  mintX: string | null, mintY: string | null,
  reserveX: bigint, reserveY: bigint
} {
  try {
    // DLMM pool layout (approximate offsets — actual offsets depend on anchor IDL)
    // Discriminator (8 bytes) + various fields
    // MintX at offset 8, MintY at offset 40, reserveX at 72, reserveY at 104
    if (data.length < 120) return { mintX: null, mintY: null, reserveX: 0n, reserveY: 0n }

    const mintX = new PublicKey(data.slice(8, 40)).toBase58()
    const mintY = new PublicKey(data.slice(40, 72)).toBase58()
    const reserveX = data.readBigUInt64LE(72)
    const reserveY = data.readBigUInt64LE(80)

    return { mintX, mintY, reserveX, reserveY }
  } catch {
    return { mintX: null, mintY: null, reserveX: 0n, reserveY: 0n }
  }
}

// ─── New pool imbalance detection ─────────────────────────────────────────────

async function detectNewPoolImbalance(
  poolAddr: string,
  mintX: string,
  mintY: string,
  liqUsd: number,
  priceX: number,
  onOpportunity: (opp: ArbOpportunity) => void
) {
  // Only act on pools < $100k liquidity (higher imbalance risk / opportunity)
  if (liqUsd > 100_000 || liqUsd < 100) return

  // Query Jupiter for cross-DEX price to find imbalance
  const [jupPriceX, jupPriceY] = await Promise.all([
    getJupiterPrice(mintX),
    getJupiterPrice(mintY),
  ])

  if (!jupPriceX || !jupPriceY) return

  const fairPrice = jupPriceX / jupPriceY
  if (fairPrice === 0) return

  const divergence = Math.abs(priceX - fairPrice) / fairPrice

  // >50x divergence from fair price with small input → arb opportunity
  if (divergence < 49) return

  const inputUsdc = Math.min(50, liqUsd * 0.01)  // max $50 or 1% of pool
  const projectedReturn = 1 + divergence

  if (projectedReturn < 500) return  // minimum 500x return threshold

  // Simulate full route
  const route = await simulateArbRoute(mintX, mintY, inputUsdc)
  if (!route) return

  const opp: ArbOpportunity = {
    tokenPair: `${mintX.slice(0,6)}/${mintY.slice(0,6)}`,
    mintX,
    mintY,
    poolAddress: poolAddr,
    estimatedInputUsdc: inputUsdc,
    projectedReturnX: projectedReturn,
    projectedReturnUsd: inputUsdc * projectedReturn,
    routeSteps: route.steps,
    recommendedJitoTipSol: calcTip(projectedReturn * inputUsdc),
    confidenceLevel: projectedReturn > 1000 ? 'HIGH' : projectedReturn > 500 ? 'MEDIUM' : 'LOW',
    detectedAt: new Date().toISOString(),
  }

  logOpportunity(opp)
  onOpportunity(opp)
}

// ─── Price imbalance detection (after large trade) ────────────────────────────

async function detectPriceImbalance(
  poolAddr: string,
  mintX: string,
  mintY: string,
  liqUsd: number,
  newPrice: number,
  oldPrice: number,
  ratio: number,
  onOpportunity: (opp: ArbOpportunity) => void
) {
  if (liqUsd < 100) return

  const direction = ratio > 1 ? 'UP' : 'DOWN'
  const inputUsdc = Math.min(50, liqUsd * 0.005)
  const projectedReturn = Math.max(ratio, 1 / ratio)

  if (projectedReturn < 10) return

  const route = await simulateArbRoute(mintX, mintY, inputUsdc)
  if (!route) return

  const opp: ArbOpportunity = {
    tokenPair: `${mintX.slice(0,6)}/${mintY.slice(0,6)}`,
    mintX,
    mintY,
    poolAddress: poolAddr,
    estimatedInputUsdc: inputUsdc,
    projectedReturnX: projectedReturn,
    projectedReturnUsd: inputUsdc * projectedReturn,
    routeSteps: route.steps,
    recommendedJitoTipSol: calcTip(projectedReturn * inputUsdc),
    confidenceLevel: projectedReturn > 100 ? 'HIGH' : projectedReturn > 10 ? 'MEDIUM' : 'LOW',
    detectedAt: new Date().toISOString(),
  }

  logOpportunity(opp)
  onOpportunity(opp)
}

// ─── Jupiter quote / route simulation ────────────────────────────────────────

interface RouteResult {
  steps: string[]
  outAmount: number
  priceImpact: number
}

async function simulateArbRoute(
  mintX: string,
  mintY: string,
  inputUsdc: number
): Promise<RouteResult | null> {
  try {
    const USDC_MINT = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'
    const inputLamports = Math.round(inputUsdc * 1_000_000) // USDC 6 decimals

    // Step 1: USDC → mintX
    const q1 = await fetch(
      `${JUPITER_QUOTE_API}/quote?inputMint=${USDC_MINT}&outputMint=${mintX}&amount=${inputLamports}&slippageBps=3000`
    ).then(r => r.json())

    if (!q1?.outAmount) return null
    if (parseFloat(q1.priceImpactPct) > 30) return null  // abort if >30% slippage

    // Step 2: mintX → mintY (via Meteora DLMM)
    const q2 = await fetch(
      `${JUPITER_QUOTE_API}/quote?inputMint=${mintX}&outputMint=${mintY}&amount=${q1.outAmount}&slippageBps=3000`
    ).then(r => r.json())

    if (!q2?.outAmount) return null

    // Step 3: mintY → USDC (to close the loop)
    const q3 = await fetch(
      `${JUPITER_QUOTE_API}/quote?inputMint=${mintY}&outputMint=${USDC_MINT}&amount=${q2.outAmount}&slippageBps=3000`
    ).then(r => r.json())

    if (!q3?.outAmount) return null

    const outUsdc = parseInt(q3.outAmount) / 1_000_000

    return {
      steps: [
        `USDC → ${mintX.slice(0,8)}`,
        `${mintX.slice(0,8)} → ${mintY.slice(0,8)} (Meteora DLMM)`,
        `${mintY.slice(0,8)} → USDC`,
      ],
      outAmount: outUsdc,
      priceImpact: parseFloat(q3.priceImpactPct ?? 0),
    }
  } catch {
    return null
  }
}

async function getJupiterPrice(mint: string): Promise<number | null> {
  try {
    const resp = await fetch(`https://price.jup.ag/v6/price?ids=${mint}`)
    const { data } = await resp.json()
    return data?.[mint]?.price ?? null
  } catch {
    return null
  }
}

async function estimateLiqUsd(
  mintX: string, mintY: string,
  reserveX: bigint, reserveY: bigint
): Promise<number> {
  try {
    const SOL_MINT = 'So11111111111111111111111111111111111111112'
    const USDC_MINT = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'

    // Quick SOL price estimate ($150 fallback)
    const solPrice = 150
    const usdcPrice = 1

    let liq = 0
    if (mintY === SOL_MINT) liq = Number(reserveY) / 1e9 * solPrice * 2
    else if (mintY === USDC_MINT) liq = Number(reserveY) / 1e6 * usdcPrice * 2
    else if (mintX === SOL_MINT) liq = Number(reserveX) / 1e9 * solPrice * 2
    else liq = Number(reserveX + reserveY) / 1e9  // rough fallback

    return liq
  } catch {
    return 0
  }
}

function calcTip(projectedProfitUsd: number): number {
  // Aggressive tip: 10-25% of projected profit, expressed in SOL
  const solPrice = 150
  const tipUsd = projectedProfitUsd * 0.15
  return Math.max(0.5, Math.min(2, tipUsd / solPrice))
}

function logOpportunity(opp: ArbOpportunity) {
  console.log(`[Meteora ARB] 🎯 ${opp.tokenPair}`)
  console.log(`  Input: $${opp.estimatedInputUsdc} USDC`)
  console.log(`  Return: ${opp.projectedReturnX.toFixed(0)}x = $${opp.projectedReturnUsd.toFixed(2)}`)
  console.log(`  Route: ${opp.routeSteps.join(' → ')}`)
  console.log(`  Jito tip: ${opp.recommendedJitoTipSol} SOL`)
  console.log(`  Confidence: ${opp.confidenceLevel}`)
}

// ─── Add to blacklist ─────────────────────────────────────────────────────────

export function blacklistToken(mint: string) {
  BLACKLIST.add(mint)
}
