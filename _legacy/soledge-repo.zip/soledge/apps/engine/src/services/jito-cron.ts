// apps/engine/src/services/jito-cron.ts
// Periodic tasks: persist Jito tip snapshots, refresh deployer profiles, clean old data

import { prisma } from './db'
import { fetchTipFloor } from './jito'
import { connection } from './helius'
import { broadcast } from '../websocket'

let snapshotInterval: NodeJS.Timeout | null = null
let slotInterval: NodeJS.Timeout | null = null

// ─── Jito tip snapshot (every 60s) ───────────────────────────────────────────

export function startJitoCron() {
  if (snapshotInterval) return

  snapshotInterval = setInterval(async () => {
    try {
      const floor = await fetchTipFloor()
      const slot = await connection.getSlot('confirmed')

      await prisma.jitoMetricSnapshot.create({
        data: {
          p25: floor.p25,
          p50: floor.p50,
          p75: floor.p75,
          p95: floor.p95,
          p99: floor.p99,
          slot: BigInt(slot),
        },
      })

      // Broadcast live metrics to dashboard
      broadcast({
        type: 'JITO_METRICS',
        data: { ...floor, slot },
      })

      // Prune old snapshots (keep last 2000 = ~33h)
      const old = await prisma.jitoMetricSnapshot.findMany({
        orderBy: { createdAt: 'desc' },
        skip: 2000,
        take: 1,
        select: { createdAt: true },
      })
      if (old[0]) {
        await prisma.jitoMetricSnapshot.deleteMany({
          where: { createdAt: { lte: old[0].createdAt } },
        })
      }
    } catch (err) {
      console.error('[JitoCron] snapshot error:', err)
    }
  }, 60_000)

  console.log('[JitoCron] Jito snapshot cron started (60s interval)')
}

// ─── Slot + TPS broadcast (every 2s) ─────────────────────────────────────────

export function startSlotBroadcast() {
  if (slotInterval) return

  slotInterval = setInterval(async () => {
    try {
      const [slot, perfSamples] = await Promise.all([
        connection.getSlot('confirmed'),
        connection.getRecentPerformanceSamples(1),
      ])

      const tps = perfSamples[0]
        ? Math.round(perfSamples[0].numTransactions / perfSamples[0].samplePeriodSecs)
        : 0

      broadcast({ type: 'SLOT_UPDATE', data: { slot, tps } })
    } catch { /* ignore */ }
  }, 2000)

  console.log('[JitoCron] Slot broadcast started (2s interval)')
}

export function stopCrons() {
  if (snapshotInterval) { clearInterval(snapshotInterval); snapshotInterval = null }
  if (slotInterval) { clearInterval(slotInterval); slotInterval = null }
}
