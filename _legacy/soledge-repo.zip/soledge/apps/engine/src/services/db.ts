// Re-export prisma from db package
export { prisma } from '@soledge/db'
