// apps/engine/src/services/scoring.ts
// Composite signal scoring — combines all signals into buy/skip/rug verdict

import { TokenSignal, SafetyChecks, MarketData, SmartMoneySignal, SentimentSignal, DeployerSignal } from '@soledge/types'
import { checkTokenSafety, getMarketData, getDeployerAddress } from './helius'
import { buildSentimentSignal } from './sentiment'
import { prisma } from './db'

// ─── Score weights ────────────────────────────────────────────────────────
// Adjust these to tune your strategy
const WEIGHTS = {
  safetyScore:    0.40,  // Hard filters dominate — safety is prerequisite
  smartMoney:     0.25,
  sentiment:      0.15,
  liquidity:      0.12,
  deployer:       0.08,
}

export async function scoreToken(mintAddress: string): Promise<TokenSignal | null> {
  // Run all checks in parallel
  const [safety, market, deployerAddr] = await Promise.all([
    checkTokenSafety(mintAddress),
    getMarketData(mintAddress),
    getDeployerAddress(mintAddress),
  ])

  // Hard rejects — don't waste time scoring
  if (!safety.mintAuthNull)   return buildRugSignal(mintAddress, 'MINT_AUTHORITY_ACTIVE', safety)
  if (!safety.freezeAuthNull) return buildRugSignal(mintAddress, 'FREEZE_AUTHORITY_ACTIVE', safety)
  if (!safety.lpLocked)       return buildRugSignal(mintAddress, 'LP_UNLOCKED', safety)

  // Liquidity too low — mathematically unviable
  if (safety.initialLiqUsd < 5_000) return null

  // Load smart money activity from DB
  const token = await prisma.tokenLaunch.findUnique({ where: { mintAddress } })
  const smartMoneySignal: SmartMoneySignal = token ? await loadSmartMoneySignal(token.id) : emptySmartMoney()

  // Sentiment
  const symbol = token?.symbol ?? mintAddress.slice(0, 6)
  const sentiment = await buildSentimentSignal(mintAddress, symbol)

  // Deployer
  const deployer = await loadDeployerSignal(deployerAddr)

  // Compute composite score
  const safetyScore   = computeSafetyScore(safety)
  const smartScore    = computeSmartMoneyScore(smartMoneySignal)
  const sentScore     = Math.round((sentiment.score + 1) / 2 * 100) // -1..1 → 0..100
  const liqScore      = computeLiqScore(safety.initialLiqUsd)
  const deployerScore = deployer.reputationScore

  const compositeScore = Math.round(
    safetyScore   * WEIGHTS.safetyScore  +
    smartScore    * WEIGHTS.smartMoney   +
    sentScore     * WEIGHTS.sentiment    +
    liqScore      * WEIGHTS.liquidity    +
    deployerScore * WEIGHTS.deployer
  )

  const recommendation = determineRecommendation(compositeScore, safety, smartMoneySignal)

  const signal: TokenSignal = {
    mintAddress,
    symbol,
    name: token?.name ?? symbol,
    safetyScore,
    compositeScore,
    checks: safety,
    market,
    smartMoney: smartMoneySignal,
    sentiment,
    deployer,
    recommendation,
  }

  // Persist signal result
  if (token) {
    await prisma.tokenLaunch.update({
      where: { id: token.id },
      data:  { safetyScore: compositeScore }
    })
  }

  return signal
}

// ─── Sub-scorers ──────────────────────────────────────────────────────────

function computeSafetyScore(s: SafetyChecks): number {
  let score = 100
  if (!s.mintAuthNull)          score -= 40  // Hard fail
  if (!s.freezeAuthNull)        score -= 40  // Hard fail
  if (!s.lpLocked)              score -= 30  // Hard fail
  if (s.top10Pct > 50)          score -= 20
  else if (s.top10Pct > 30)     score -= 10
  if (s.isBundled)              score -= 15
  if (s.initialLiqUsd < 10_000) score -= 10
  return Math.max(0, score)
}

function computeSmartMoneyScore(s: SmartMoneySignal): number {
  let score = 50
  score += Math.min(s.activeWallets * 10, 40)   // Up to +40 for 4+ wallets
  score += Math.min(s.totalBoughtSol * 2, 20)   // Up to +20 for 10+ SOL
  if (s.isCoordinated)              score += 10
  if (s.coordinatedExitDetected)    score  = 0   // Override — smart money leaving
  return Math.max(0, Math.min(100, score))
}

function computeLiqScore(liq: number): number {
  if (liq >= 100_000) return 100
  if (liq >= 50_000)  return 80
  if (liq >= 20_000)  return 60
  if (liq >= 10_000)  return 40
  if (liq >= 5_000)   return 20
  return 0
}

function determineRecommendation(
  score: number,
  safety: SafetyChecks,
  smart: SmartMoneySignal
): TokenSignal['recommendation'] {
  if (!safety.mintAuthNull || !safety.freezeAuthNull) return 'RUG'
  if (smart.coordinatedExitDetected) return 'SKIP'
  if (score >= 75) return 'BUY'
  if (score >= 50) return 'WATCH'
  return 'SKIP'
}

function buildRugSignal(
  mintAddress: string,
  reason: string,
  safety: SafetyChecks
): TokenSignal {
  return {
    mintAddress,
    symbol: mintAddress.slice(0, 6),
    name: mintAddress.slice(0, 6),
    safetyScore: 0,
    compositeScore: 0,
    checks: safety,
    market: emptyMarket(),
    smartMoney: emptySmartMoney(),
    sentiment: emptySentiment(),
    deployer: emptyDeployer(),
    recommendation: 'RUG',
  }
}

async function loadSmartMoneySignal(tokenId: string): Promise<SmartMoneySignal> {
  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000)
  const activities = await prisma.smartMoneyActivity.findMany({
    where: { tokenId, createdAt: { gte: fiveMinAgo } },
    orderBy: { createdAt: 'desc' },
  })

  const buys  = activities.filter(a => a.action === 'BUY')
  const sells = activities.filter(a => a.action === 'SELL')

  return {
    activeWallets:            new Set(activities.map(a => a.walletId)).size,
    totalBoughtSol:           buys.reduce((s, a) => s + a.amountSol, 0),
    walletLabels:             [],
    avgWalletScore:           0,
    isCoordinated:            buys.length >= 3,
    coordinatedExitDetected:  sells.length >= 3,
  }
}

async function loadDeployerSignal(address: string | null): Promise<DeployerSignal> {
  if (!address) return emptyDeployer()

  const profile = await prisma.deployerProfile.findUnique({ where: { address } })
  if (!profile) return { address, reputationScore: 50, previousLaunches: 0, previousRugs: 0, tags: [], isKnownBad: false }

  return {
    address,
    reputationScore: profile.reputationScore,
    previousLaunches: profile.totalLaunches,
    previousRugs: profile.rugs,
    tags: profile.tags,
    isKnownBad: profile.rugs > 2 || profile.reputationScore < 20,
  }
}

// ─── Empty defaults ───────────────────────────────────────────────────────

function emptyMarket(): MarketData {
  return { priceUsd:0,mcapUsd:0,liqUsd:0,volume5m:0,volume1h:0,priceChange5m:0,priceChange1h:0,txCount5m:0,buyCount5m:0,sellCount5m:0,buyPressure:0 }
}
function emptySmartMoney(): SmartMoneySignal {
  return { activeWallets:0,totalBoughtSol:0,walletLabels:[],avgWalletScore:0,isCoordinated:false,coordinatedExitDetected:false }
}
function emptySentiment(): SentimentSignal {
  return { score:0,velocity:0,platforms:{twitter:0,telegram:0,discord:0},trending:false }
}
function emptyDeployer(): DeployerSignal {
  return { address:'',reputationScore:50,previousLaunches:0,previousRugs:0,tags:[],isKnownBad:false }
}
