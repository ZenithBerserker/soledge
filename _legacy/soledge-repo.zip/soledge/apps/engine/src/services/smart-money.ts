// apps/engine/src/services/smart-money.ts
// Real-time smart money wallet tracking via Yellowstone gRPC

import { connection } from './helius'
import { PublicKey, ParsedTransactionWithMeta } from '@solana/web3.js'
import { SmartMoneySignal, SmartMoneyEvent, WsEvent } from '@soledge/types'
import { prisma } from './db'
import { broadcast } from '../websocket'

// ─── Wallet tracking ──────────────────────────────────────────────────────

const trackedWallets = new Map<string, { label: string; score: number }>()
const subscriptions  = new Map<string, number>() // address → subscription id

export async function loadTrackedWallets() {
  const wallets = await prisma.smartWallet.findMany({
    where: { trustScore: { gte: 50 } },
    orderBy: { trustScore: 'desc' },
  })

  for (const w of wallets) {
    trackedWallets.set(w.address, {
      label: w.label ?? w.category,
      score: w.trustScore,
    })
  }

  console.log(`[SmartMoney] Loaded ${trackedWallets.size} wallets`)
}

export async function subscribeToWallet(address: string) {
  if (subscriptions.has(address)) return

  const pubkey = new PublicKey(address)

  const subId = connection.onAccountChange(pubkey, async (info, ctx) => {
    // Account balance changed — fetch recent tx
    try {
      const sigs = await connection.getSignaturesForAddress(pubkey, { limit: 1 })
      if (!sigs.length) return

      const [tx] = await connection.getParsedTransactions([sigs[0].signature], {
        maxSupportedTransactionVersion: 0,
      })
      if (!tx) return

      await processTx(address, tx, ctx.slot)
    } catch (err) {
      console.error('[SmartMoney] processTx error:', err)
    }
  })

  subscriptions.set(address, subId)
}

export async function subscribeAll() {
  for (const address of trackedWallets.keys()) {
    await subscribeToWallet(address)
    // Rate limit to avoid RPC throttling
    await new Promise(r => setTimeout(r, 50))
  }
}

// ─── Transaction analysis ─────────────────────────────────────────────────

async function processTx(
  walletAddress: string,
  tx: ParsedTransactionWithMeta,
  slot: number
) {
  const meta   = tx.meta
  const msg    = tx.transaction.message
  if (!meta || meta.err) return

  // Detect swap instructions (Raydium, Jupiter, Orca, etc.)
  const DEX_PROGRAMS = [
    '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8', // Raydium v4
    'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',  // Jupiter v6
    '9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP', // Orca Whirlpools
  ]

  const programIds = (msg as any).accountKeys?.map((k: any) => k.pubkey?.toString?.() ?? k.toString()) ?? []
  const isDexTx = programIds.some((p: string) => DEX_PROGRAMS.includes(p))
  if (!isDexTx) return

  // Determine token being swapped
  const postTokenBalances  = meta.postTokenBalances  ?? []
  const preTokenBalances   = meta.preTokenBalances   ?? []
  const tokenDeltas: Record<string, number> = {}

  for (const post of postTokenBalances) {
    const pre = preTokenBalances.find(p => p.accountIndex === post.accountIndex)
    const preAmt  = pre?.uiTokenAmount?.uiAmount  ?? 0
    const postAmt = post.uiTokenAmount?.uiAmount  ?? 0
    const mint    = post.mint
    if (Math.abs(postAmt - preAmt) > 0) tokenDeltas[mint] = postAmt - preAmt
  }

  const SOL_MINT = 'So11111111111111111111111111111111111111112'
  const tokens   = Object.entries(tokenDeltas).filter(([m]) => m !== SOL_MINT)
  if (!tokens.length) return

  const [mintAddress, delta] = tokens[0]
  const action = delta > 0 ? 'BUY' : 'SELL'
  const solDelta = Math.abs(tokenDeltas[SOL_MINT] ?? 0)

  // Find or create token in DB
  let token = await prisma.tokenLaunch.findUnique({ where: { mintAddress } })
  if (!token) return // Only track known tokens

  // Persist activity
  const wallet = await prisma.smartWallet.findUnique({ where: { address: walletAddress } })
  if (!wallet) return

  await prisma.smartMoneyActivity.create({
    data: {
      walletId:    wallet.id,
      tokenId:     token.id,
      action:      action as any,
      amountSol:   solDelta,
      slot:        BigInt(slot),
      txSignature: tx.transaction.signatures[0],
    }
  }).catch(() => {}) // ignore duplicate sig

  // Broadcast to dashboard
  const event: WsEvent = {
    type: 'SMART_MONEY',
    data: {
      walletAddress,
      walletLabel: trackedWallets.get(walletAddress)?.label ?? 'UNKNOWN',
      walletScore: trackedWallets.get(walletAddress)?.score ?? 0,
      mintAddress,
      symbol: token.symbol ?? mintAddress.slice(0, 6),
      action: action as 'BUY' | 'SELL',
      amountSol: solDelta,
      slot,
    } satisfies SmartMoneyEvent
  }
  broadcast(event)

  // Check for coordinated exit (multiple smart wallets selling same token)
  if (action === 'SELL') await detectCoordinatedExit(mintAddress, slot)
}

// ─── Coordinated exit detection ───────────────────────────────────────────

const exitBuffer = new Map<string, { wallets: string[]; slot: number }>()

async function detectCoordinatedExit(mintAddress: string, slot: number) {
  const existing = exitBuffer.get(mintAddress)
  const windowSlots = 3

  if (!existing || slot - existing.slot > windowSlots) {
    exitBuffer.set(mintAddress, { wallets: [], slot })
  }

  const entry = exitBuffer.get(mintAddress)!
  entry.wallets.push(mintAddress)

  // 3+ tracked wallets exiting in same slot window = coordinated dump
  if (entry.wallets.length >= 3) {
    exitBuffer.delete(mintAddress)

    const token = await prisma.tokenLaunch.findUnique({ where: { mintAddress } })
    if (!token) return

    // Create alert
    await prisma.alphaAlert.create({
      data: {
        tokenId: token.id,
        type:    'COORDINATED_EXIT',
        tier:    'PRO',
        title:   `COORDINATED EXIT: $${token.symbol}`,
        body:    `${entry.wallets.length} smart money wallets simultaneously exiting $${token.symbol}. Sell pressure incoming.`,
        metadata: { mintAddress, wallets: entry.wallets, slot }
      }
    })

    broadcast({
      type: 'SMART_MONEY',
      data: {
        walletAddress: 'COORDINATED',
        walletLabel: 'COORDINATED EXIT',
        walletScore: 100,
        mintAddress,
        symbol: token.symbol ?? '',
        action: 'SELL',
        amountSol: 0,
        slot,
      }
    })
  }
}

// ─── Smart money score calculation ───────────────────────────────────────

export function computeSmartMoneySignal(
  mintAddress: string,
  recentActivities: Array<{ walletId: string; action: string; amountSol: number; createdAt: Date }>
): SmartMoneySignal {
  const buys  = recentActivities.filter(a => a.action === 'BUY')
  const sells = recentActivities.filter(a => a.action === 'SELL')

  const activeWallets   = new Set(recentActivities.map(a => a.walletId)).size
  const totalBoughtSol  = buys.reduce((s, a) => s + a.amountSol, 0)

  // Detect if multiple wallets bought within same minute (coordinated entry)
  const buyTimes = buys.map(b => Math.floor(b.createdAt.getTime() / 60000))
  const timeGroups = buyTimes.reduce((acc: Record<number, number>, t) => {
    acc[t] = (acc[t] || 0) + 1
    return acc
  }, {})
  const isCoordinated = Object.values(timeGroups).some(c => c >= 3)
  const coordinatedExitDetected = sells.length >= 3

  return {
    activeWallets,
    totalBoughtSol,
    walletLabels: [],
    avgWalletScore: 0,
    isCoordinated,
    coordinatedExitDetected,
  }
}
