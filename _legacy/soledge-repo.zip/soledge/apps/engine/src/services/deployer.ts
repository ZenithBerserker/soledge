// apps/engine/src/services/deployer.ts
// Deployer reputation tracking — builds and maintains on-chain deployer profiles

import { prisma } from './db'
import { getDeployerAddress, getHistoricalTransactions } from './helius'

// ─── Update or create deployer profile ───────────────────────────────────────

export async function upsertDeployerProfile(
  mintAddress: string,
  isRug: boolean,
  liqUsd: number
): Promise<void> {
  const deployer = await getDeployerAddress(mintAddress)
  if (!deployer) return

  const existing = await prisma.deployerProfile.findUnique({
    where: { address: deployer },
  })

  const rugCount = (existing?.rugs ?? 0) + (isRug ? 1 : 0)
  const launches = (existing?.totalLaunches ?? 0) + 1
  const successes = (existing?.successfulExits ?? 0) + (!isRug && liqUsd > 10_000 ? 1 : 0)

  // Reputation score:
  // Start at 50. Rugs -15 each, successes +10 each, longevity bonus
  const rugPenalty = rugCount * 15
  const successBonus = successes * 10
  const reputationScore = Math.max(0, Math.min(100, 50 - rugPenalty + successBonus))

  const tags: string[] = []
  if (rugCount > 2) tags.push('SERIAL_RUGGER')
  if (rugCount === 0 && successes > 3) tags.push('LEGIT_DEV')
  if (launches > 10 && rugCount / launches > 0.5) tags.push('HIGH_RUG_RATE')

  await prisma.deployerProfile.upsert({
    where: { address: deployer },
    create: {
      address: deployer,
      totalLaunches: 1,
      rugs: isRug ? 1 : 0,
      successfulExits: !isRug && liqUsd > 10_000 ? 1 : 0,
      avgLiqUsd: liqUsd,
      reputationScore,
      tags,
      lastSeen: new Date(),
    },
    update: {
      totalLaunches: { increment: 1 },
      rugs: isRug ? { increment: 1 } : undefined,
      successfulExits: !isRug && liqUsd > 10_000 ? { increment: 1 } : undefined,
      reputationScore,
      tags,
      lastSeen: new Date(),
    },
  })
}

// ─── Flag a token as rugged and update deployer ───────────────────────────────

export async function markTokenRugged(
  mintAddress: string,
  rugType: string,
  lossUsd: number
): Promise<void> {
  await prisma.tokenLaunch.updateMany({
    where: { mintAddress },
    data: { isRug: true, rugType, ruggedAt: new Date() },
  })
  await upsertDeployerProfile(mintAddress, true, 0)

  console.log(`[Deployer] Marked ${mintAddress.slice(0,8)} as RUG (${rugType}) loss=$${lossUsd}`)
}
