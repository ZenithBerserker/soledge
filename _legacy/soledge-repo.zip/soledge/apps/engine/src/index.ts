// apps/engine/src/index.ts
// SolEdge Engine — main entry point

import 'dotenv/config'
import { startWebSocketServer, broadcast } from './websocket'
import { subscribeRaydiumLaunches } from './services/helius'
import { scoreToken } from './services/scoring'
import { loadTrackedWallets, subscribeAll } from './services/smart-money'
import { subscribeMeteoraLaunches, blacklistToken } from './services/meteora'
import { startJitoCron, startSlotBroadcast } from './services/jito-cron'
import { upsertDeployerProfile } from './services/deployer'
import { prisma } from './services/db'
import type { ArbOpportunity } from './services/meteora'

async function main() {
  console.log('🚀 SolEdge Engine starting...')

  // 1. Start WebSocket server for dashboard + bots
  startWebSocketServer()

  // 2. Start cron jobs
  startJitoCron()
  startSlotBroadcast()

  // 3. Load smart money wallets
  await loadTrackedWallets()
  await subscribeAll()

  // 4. Subscribe to Raydium launches
  await subscribeRaydiumLaunches(async (mintAddress, poolAddress, slot) => {
    console.log(`[Engine] New Raydium pool: ${mintAddress.slice(0,8)} @ slot ${slot}`)
    await processNewToken(mintAddress, poolAddress, slot, 'RAYDIUM')
  })

  // 5. Subscribe to Meteora launches and arb opportunities
  await subscribeMeteoraLaunches(async (opp: ArbOpportunity) => {
    console.log(`[Engine] Meteora ARB opportunity: ${opp.tokenPair} ${opp.projectedReturnX.toFixed(0)}x`)

    // Broadcast to dashboard
    broadcast({
      type: 'TOKEN_LAUNCH',
      data: {
        mintAddress: opp.mintX,
        symbol: opp.tokenPair,
        name: `ARB: ${opp.tokenPair}`,
        safetyScore: opp.confidenceLevel === 'HIGH' ? 90 : opp.confidenceLevel === 'MEDIUM' ? 70 : 50,
        compositeScore: Math.min(99, Math.round(opp.projectedReturnX / 10)),
        recommendation: 'BUY' as const,
        checks: {
          mintAuthNull: true,
          freezeAuthNull: true,
          lpLocked: true,
          lpLockDays: null,
          lpLockPlatform: 'METEORA',
          top10Pct: 0,
          isBundled: false,
          initialLiqUsd: opp.estimatedInputUsdc * opp.projectedReturnX,
        },
        market: {
          priceUsd: 0, mcapUsd: 0, liqUsd: 0,
          volume5m: opp.estimatedInputUsdc, volume1h: 0,
          priceChange5m: opp.projectedReturnX * 100, priceChange1h: 0,
          txCount5m: 0, buyCount5m: 0, sellCount5m: 0, buyPressure: 1,
        },
        smartMoney: { activeWallets: 0, totalBoughtSol: 0, walletLabels: [], avgWalletScore: 0, isCoordinated: false, coordinatedExitDetected: false },
        sentiment: { score: 0.8, velocity: 0, platforms: { twitter: 0, telegram: 0, discord: 0 }, trending: false },
        deployer: { address: '', reputationScore: 50, previousLaunches: 0, previousRugs: 0, tags: ['METEORA_ARB'], isKnownBad: false },
        jitoBundle: {
          tip: Math.round(opp.recommendedJitoTipSol * 1e9),
          transactions: [],
          bundleOnly: true,
          dontfront: true,
        },
      },
    })

    // Persist to DB as alert
    await prisma.alphaAlert.create({
      data: {
        type: 'ALPHA_SIGNAL',
        tier: 'ELITE',
        title: `🎯 METEORA ARB: ${opp.tokenPair}`,
        body: `${opp.projectedReturnX.toFixed(0)}x return | $${opp.estimatedInputUsdc} → $${opp.projectedReturnUsd.toFixed(0)} | Tip: ${opp.recommendedJitoTipSol} SOL | ${opp.confidenceLevel} confidence`,
        metadata: opp as any,
      }
    }).catch(() => {})
  })

  console.log('✅ SolEdge Engine running')
  console.log('   → Raydium + Meteora subscriptions active')
  console.log('   → Smart money tracking active')
  console.log('   → Jito snapshot cron active')

  // Graceful shutdown
  process.on('SIGINT', async () => {
    console.log('\nShutting down gracefully...')
    await prisma.$disconnect()
    process.exit(0)
  })
}

// ─── Token processing pipeline ────────────────────────────────────────────────

async function processNewToken(
  mintAddress: string,
  poolAddress: string,
  slot: number,
  source: 'RAYDIUM' | 'METEORA'
) {
  try {
    // Upsert into DB
    await prisma.tokenLaunch.upsert({
      where: { mintAddress },
      update: { updatedAt: new Date() },
      create: {
        mintAddress,
        deployerWallet: 'unknown',
        launchSlot: BigInt(slot),
        launchTime: new Date(),
        ...(source === 'RAYDIUM' ? { raydiumPool: poolAddress } : {}),
      },
    })

    // Run full scoring pipeline
    const signal = await scoreToken(mintAddress)

    if (!signal) {
      console.log(`[Engine] ${mintAddress.slice(0,8)} rejected by filters`)
      return
    }

    console.log(`[Engine] ${signal.symbol} → ${signal.recommendation} (${signal.compositeScore}/100)`)

    // Update deployer reputation
    await upsertDeployerProfile(mintAddress, signal.recommendation === 'RUG', signal.checks.initialLiqUsd)

    // Create alert
    if (signal.recommendation === 'BUY' || signal.recommendation === 'RUG') {
      const tier = signal.recommendation === 'RUG' ? 'FREE' : 'PRO'
      await prisma.alphaAlert.create({
        data: {
          type: signal.recommendation === 'RUG' ? 'RUG_DETECTED' : 'ALPHA_SIGNAL',
          tier: tier as any,
          title: signal.recommendation === 'RUG'
            ? `☠️ RUG: $${signal.symbol}`
            : `⚡ ALPHA: $${signal.symbol}`,
          body: `Score: ${signal.compositeScore}/100 | Safety: ${signal.safetyScore}/100 | Liq: $${signal.checks.initialLiqUsd.toFixed(0)}`,
          metadata: signal as any,
          token: { connect: { mintAddress } },
        },
      }).catch(() => {})
    }

    // Broadcast to all WebSocket clients
    broadcast({ type: signal.recommendation === 'RUG' ? 'RUG_ALERT' : 'TOKEN_LAUNCH', data: signal as any })

  } catch (err) {
    console.error(`[Engine] Error processing ${mintAddress.slice(0,8)}:`, err)
  }
}

main().catch(console.error)
