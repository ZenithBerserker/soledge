import { cn } from '@/lib/utils'
import type { LucideIcon } from 'lucide-react'

interface StatCardProps {
  label: string
  value: string | number
  sub?: string
  icon: LucideIcon
  color?: 'brand' | 'danger' | 'warn' | 'info'
  trend?: 'up' | 'down'
}

const colorMap = {
  brand: 'text-brand bg-brand/10 border-brand/20',
  danger: 'text-danger bg-danger/10 border-danger/20',
  warn: 'text-warn bg-warn/10 border-warn/20',
  info: 'text-info bg-info/10 border-info/20',
}

export function StatCard({ label, value, sub, icon: Icon, color = 'brand', trend }: StatCardProps) {
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={cn('w-9 h-9 rounded-lg border flex items-center justify-center', colorMap[color])}>
          <Icon className="w-4 h-4" />
        </div>
        {trend && (
          <span className={cn('text-xs font-mono', trend === 'up' ? 'text-brand' : 'text-danger')}>
            {trend === 'up' ? '↑' : '↓'}
          </span>
        )}
      </div>
      <div className="text-2xl font-mono font-bold text-white mb-0.5">{value}</div>
      <div className="text-xs text-slate-400">{label}</div>
      {sub && <div className="text-xs text-slate-600 mt-0.5">{sub}</div>}
    </div>
  )
}
