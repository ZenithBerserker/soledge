'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Zap, LayoutDashboard, Shield, Wallet, TrendingUp, BarChart3, Settings, LogOut, BookOpen, Target } from 'lucide-react'
import { signOut, useSession } from 'next-auth/react'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'Overview', exact: true },
  { href: '/dashboard/signals', icon: Zap, label: 'Alpha Signals' },
  { href: '/dashboard/rugs', icon: Shield, label: 'Rug Alerts' },
  { href: '/dashboard/wallets', icon: Wallet, label: 'Smart Money' },
  { href: '/dashboard/arb', icon: Target, label: 'Meteora ARB', tier: 'ELITE' },
  { href: '/dashboard/jito', icon: BarChart3, label: 'Jito Metrics' },
  { href: "/dashboard/tokens", icon: TrendingUp, label: "Tokens" },
  { href: "/dashboard/settings", icon: Settings, label: "Settings" },
]

export function Sidebar() {
  const pathname = usePathname()
  const { data: session } = useSession()
  const role = (session?.user as any)?.role ?? 'FREE'

  return (
    <aside className="w-60 h-screen flex flex-col bg-surface-raised border-r border-surface-border fixed left-0 top-0 z-20">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-surface-border">
        <div className="w-8 h-8 rounded-lg bg-brand/20 border border-brand/40 flex items-center justify-center">
          <Zap className="w-4 h-4 text-brand" />
        </div>
        <span className="font-display font-700 text-white">SolEdge</span>
        <span className={cn(
          'ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded border',
          role === 'FREE' ? 'text-slate-500 border-slate-700' :
          role === 'PRO' ? 'text-brand border-brand/40 bg-brand/5' :
          'text-warn border-warn/40 bg-warn/5'
        )}>
          {role}
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV.map(({ href, icon: Icon, label, exact, tier }) => {
          const active = exact ? pathname === href : pathname.startsWith(href)
          const locked = tier === 'ELITE' && role !== 'ELITE' && role !== 'ADMIN'
          return (
            <Link
              key={href}
              href={locked ? '/upgrade' : href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all',
                active && !locked
                  ? 'bg-brand/10 text-brand border border-brand/20'
                  : locked
                  ? 'text-slate-600 hover:text-slate-500 cursor-pointer'
                  : 'text-slate-400 hover:text-white hover:bg-surface-hover'
              )}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="flex-1">{label}</span>
              {tier && (
                <span className={cn(
                  'text-[9px] font-mono px-1 py-0.5 rounded border',
                  locked ? 'text-slate-700 border-slate-800' : 'text-warn/70 border-warn/20'
                )}>
                  {tier}
                </span>
              )}
            </Link>
          )
        })}
      </nav>

      {/* Bottom */}
      <div className="px-3 py-4 border-t border-surface-border space-y-1 shrink-0">
        <Link href="/docs" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-400 hover:text-white hover:bg-surface-hover transition-all">
          <BookOpen className="w-4 h-4" />
          Docs & API
        </Link>
        <Link href="/upgrade" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-400 hover:text-white hover:bg-surface-hover transition-all">
          <Settings className="w-4 h-4" />
          Upgrade Plan
        </Link>
        <button
          onClick={() => signOut({ callbackUrl: '/' })}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-400 hover:text-danger hover:bg-danger/5 transition-all"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </aside>
  )
}
