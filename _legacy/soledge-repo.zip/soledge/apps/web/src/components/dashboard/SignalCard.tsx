'use client'
import { ExternalLink, Shield, TrendingUp, Brain, Zap } from 'lucide-react'
import { cn, formatUsd, truncate, recommendationColor, scoreColor } from '@/lib/utils'

interface SignalCardProps {
  alert: {
    id: string
    type: string
    tier: string
    title: string
    body: string
    createdAt: string
    metadata?: any
    token?: {
      mintAddress: string
      symbol?: string
      safetyScore?: number
    }
  }
}

export function SignalCard({ alert }: SignalCardProps) {
  const meta = alert.metadata as any
  const isRug = alert.type === 'RUG_DETECTED'
  const mint = alert.token?.mintAddress ?? meta?.mintAddress

  return (
    <div className={cn(
      'card p-4 hover:border-surface-border/80 transition-all animate-slide-in',
      isRug && 'border-danger/20 hover:border-danger/30'
    )}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            {/* Recommendation badge */}
            {meta?.recommendation && (
              <span className={cn('text-xs font-mono px-2 py-0.5 rounded border', recommendationColor(meta.recommendation))}>
                {meta.recommendation}
              </span>
            )}
            {/* Tier badge */}
            <span className={cn(
              'text-xs px-2 py-0.5 rounded border font-mono',
              alert.tier === 'FREE' ? 'text-slate-500 border-slate-700' :
              alert.tier === 'PRO' ? 'text-brand/70 border-brand/20' :
              'text-warn/70 border-warn/20'
            )}>
              {alert.tier}
            </span>
            <span className="text-xs text-slate-600 ml-auto font-mono">
              {new Date(alert.createdAt).toLocaleTimeString()}
            </span>
          </div>

          <h3 className="font-mono text-sm font-600 text-white mb-1">{alert.title}</h3>
          <p className="text-xs text-slate-400 mb-3">{alert.body}</p>

          {/* Score row */}
          {meta?.compositeScore !== undefined && (
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-1.5">
                <Zap className="w-3 h-3 text-slate-500" />
                <span className="text-slate-500">Score:</span>
                <span className={scoreColor(meta.compositeScore)}>{meta.compositeScore}/100</span>
              </div>
              {meta?.checks?.initialLiqUsd > 0 && (
                <div className="flex items-center gap-1.5">
                  <TrendingUp className="w-3 h-3 text-slate-500" />
                  <span className="text-slate-500">Liq:</span>
                  <span className="text-white">{formatUsd(meta.checks.initialLiqUsd)}</span>
                </div>
              )}
              {meta?.smartMoney?.activeWallets > 0 && (
                <div className="flex items-center gap-1.5">
                  <Brain className="w-3 h-3 text-slate-500" />
                  <span className="text-slate-500">Smart$:</span>
                  <span className="text-info">{meta.smartMoney.activeWallets} wallets</span>
                </div>
              )}
              {meta?.checks && (
                <div className="flex items-center gap-1.5">
                  <Shield className="w-3 h-3 text-slate-500" />
                  <span className={meta.checks.mintAuthNull && meta.checks.freezeAuthNull && meta.checks.lpLocked ? 'text-brand' : 'text-danger'}>
                    {meta.checks.mintAuthNull && meta.checks.freezeAuthNull && meta.checks.lpLocked ? '✓ Safe' : '✗ Unsafe'}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Links */}
        {mint && (
          <div className="flex flex-col gap-1.5 shrink-0">
            <a
              href={`https://dexscreener.com/solana/${mint}`}
              target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-brand transition-colors px-2 py-1 rounded border border-surface-border hover:border-brand/30"
            >
              DEX <ExternalLink className="w-2.5 h-2.5" />
            </a>
            <a
              href={`https://jup.ag/swap/SOL-${mint}`}
              target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-brand transition-colors px-2 py-1 rounded border border-surface-border hover:border-brand/30"
            >
              JUP <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>
        )}
      </div>

      {/* Mint address */}
      {mint && (
        <div className="mt-3 pt-3 border-t border-surface-border/50 flex items-center gap-2">
          <span className="text-xs font-mono text-slate-600">{truncate(mint, 8, 8)}</span>
          <button
            onClick={() => navigator.clipboard.writeText(mint)}
            className="text-xs text-slate-600 hover:text-brand transition-colors"
          >
            copy
          </button>
        </div>
      )}
    </div>
  )
}
