'use client'
import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { Zap, Shield, Brain, TrendingUp } from 'lucide-react'

interface FeedEvent {
  id: string
  type: string
  data: any
  ts: number
}

const EVENT_ICONS: Record<string, any> = {
  TOKEN_LAUNCH: Zap,
  RUG_ALERT: Shield,
  SMART_MONEY: Brain,
  SENTIMENT_SURGE: TrendingUp,
}

const EVENT_COLORS: Record<string, string> = {
  TOKEN_LAUNCH: 'text-brand border-brand/30 bg-brand/5',
  RUG_ALERT: 'text-danger border-danger/30 bg-danger/5',
  SMART_MONEY: 'text-info border-info/30 bg-info/5',
  SENTIMENT_SURGE: 'text-warn border-warn/30 bg-warn/5',
}

export function LiveFeed() {
  const [events, setEvents] = useState<FeedEvent[]>([])
  const [connected, setConnected] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    const wsUrl = process.env.NEXT_PUBLIC_WS_URL ?? 'ws://localhost:3001'

    function connect() {
      try {
        const ws = new WebSocket(wsUrl)
        wsRef.current = ws

        ws.onopen = () => setConnected(true)
        ws.onclose = () => {
          setConnected(false)
          setTimeout(connect, 3000)
        }
        ws.onmessage = (e) => {
          try {
            const event = JSON.parse(e.data)
            if (event.type === 'PONG' || event.type === 'CONNECTED') return
            setEvents(prev => [{
              id: `${Date.now()}-${Math.random()}`,
              type: event.type,
              data: event.data,
              ts: Date.now(),
            }, ...prev].slice(0, 50))
          } catch {}
        }
      } catch {}
    }

    connect()
    return () => wsRef.current?.close()
  }, [])

  // Ping keepalive
  useEffect(() => {
    const id = setInterval(() => {
      if (wsRef.current?.readyState === 1) {
        wsRef.current.send(JSON.stringify({ type: 'PING' }))
      }
    }, 15000)
    return () => clearInterval(id)
  }, [])

  return (
    <div className="card flex flex-col h-full">
      <div className="flex items-center justify-between px-5 py-4 border-b border-surface-border">
        <h3 className="font-display font-600 text-white text-sm">Live Event Feed</h3>
        <div className="flex items-center gap-1.5 text-xs font-mono">
          <span className={cn('w-1.5 h-1.5 rounded-full', connected ? 'bg-brand blink' : 'bg-slate-600')} />
          <span className={connected ? 'text-brand' : 'text-slate-600'}>
            {connected ? 'CONNECTED' : 'DISCONNECTED'}
          </span>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
        {events.length === 0 && (
          <div className="text-center py-12 text-sm text-slate-600 font-mono">
            Waiting for events...<br />
            <span className="text-xs">(Start the engine to see live data)</span>
          </div>
        )}
        {events.map(ev => {
          const Icon = EVENT_ICONS[ev.type] ?? Zap
          const colorClass = EVENT_COLORS[ev.type] ?? 'text-slate-400 border-slate-700 bg-slate-800/20'
          return (
            <div key={ev.id} className="flex items-start gap-2.5 animate-slide-in">
              <div className={cn('shrink-0 w-6 h-6 rounded border flex items-center justify-center mt-0.5', colorClass)}>
                <Icon className="w-3 h-3" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className={cn('text-[10px] font-mono', colorClass.split(' ')[0])}>{ev.type.replace(/_/g,' ')}</span>
                  <span className="text-[10px] font-mono text-slate-700">{new Date(ev.ts).toLocaleTimeString()}</span>
                </div>
                <p className="text-xs text-slate-400 truncate">
                  {ev.data?.symbol ?? ev.data?.mintAddress?.slice(0,12) ?? JSON.stringify(ev.data).slice(0,60)}
                </p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
