// apps/web/src/components/dashboard/JitoMetricsCard.tsx

interface Snapshot {
  p25: number; p50: number; p75: number; p95: number; p99: number;
} | null

export function JitoMetricsCard({ snapshot }: { snapshot: Snapshot }) {
  const tiers = [
    { label: 'P25 (economy)',  val: snapshot?.p25 ?? 0, color: 'bg-text-muted' },
    { label: 'P50 (standard)', val: snapshot?.p50 ?? 0, color: 'bg-accent-blue' },
    { label: 'P75 (fast)',     val: snapshot?.p75 ?? 0, color: 'bg-accent-yellow' },
    { label: 'P95 (priority)', val: snapshot?.p95 ?? 0, color: 'bg-accent-green' },
    { label: 'P99 (ultra)',    val: snapshot?.p99 ?? 0, color: 'bg-accent-purple' },
  ]

  const max = Math.max(...tiers.map(t => t.val), 1)

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-bg-border">
        <h2 className="font-display font-semibold text-sm text-text-primary">⚙️ Jito Tip Floor</h2>
        <span className="text-[10px] font-mono text-text-muted">LAMPORTS</span>
      </div>
      <div className="p-4 space-y-2.5">
        {tiers.map(tier => (
          <div key={tier.label}>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-text-secondary font-mono">{tier.label}</span>
              <span className="text-text-primary font-mono font-bold">{tier.val.toLocaleString()}</span>
            </div>
            <div className="score-bar">
              <div
                className={`score-fill ${tier.color}`}
                style={{ width: `${(tier.val / max) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="px-4 pb-3">
        <div className="text-[10px] text-text-muted font-mono text-center">
          {snapshot ? 'LIVE FROM JITO REST API' : 'ENGINE OFFLINE — START ENGINE TO POPULATE'}
        </div>
      </div>
    </div>
  )
}
