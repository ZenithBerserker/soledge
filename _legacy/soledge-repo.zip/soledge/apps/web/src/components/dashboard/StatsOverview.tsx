// apps/web/src/components/dashboard/StatsOverview.tsx

interface Props {
  totalTokens: number
  rugCount: number
  buySignals: number
  smartWallets: number
}

export function StatsOverview({ totalTokens, rugCount, buySignals, smartWallets }: Props) {
  const stats = [
    { label: 'Tokens Scanned', value: totalTokens.toLocaleString(), icon: '🔍', color: 'text-accent-blue', subtext: 'all time' },
    { label: 'Rugs Detected', value: rugCount.toLocaleString(), icon: '☠️', color: 'text-accent-red', subtext: 'protected' },
    { label: 'BUY Signals', value: buySignals.toLocaleString(), icon: '⚡', color: 'text-accent-green', subtext: 'high conviction' },
    { label: 'Smart Wallets', value: smartWallets.toLocaleString(), icon: '🐋', color: 'text-accent-purple', subtext: 'tracked live' },
  ]

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map(s => (
        <div key={s.label} className="card p-4">
          <div className="flex items-start justify-between mb-2">
            <span className="text-text-muted text-xs font-mono uppercase tracking-wider">{s.label}</span>
            <span className="text-xl">{s.icon}</span>
          </div>
          <div className={`font-display font-bold text-2xl ${s.color} mb-0.5`}>{s.value}</div>
          <div className="text-text-muted text-xs">{s.subtext}</div>
        </div>
      ))}
    </div>
  )
}
