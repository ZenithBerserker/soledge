'use client'
import { useSession } from 'next-auth/react'
import { Bell, Wifi } from 'lucide-react'
import { useState, useEffect } from 'react'

export function TopBar({ title }: { title: string }) {
  const { data: session } = useSession()
  const [time, setTime] = useState<string>('')
  const [slot, setSlot] = useState<number | null>(null)

  useEffect(() => {
    const tick = () => setTime(new Date().toLocaleTimeString('en-US', { hour12: false }))
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [])

  return (
    <header className="h-14 border-b border-surface-border flex items-center justify-between px-6">
      <h1 className="font-display font-600 text-white">{title}</h1>
      <div className="flex items-center gap-5">
        {/* Live indicator */}
        <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
          <Wifi className="w-3.5 h-3.5 text-brand" />
          <span className="text-brand">LIVE</span>
          <span>{time}</span>
        </div>
        <button className="relative p-2 rounded-lg hover:bg-surface-hover transition-colors">
          <Bell className="w-4 h-4 text-slate-400" />
          <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-brand blink" />
        </button>
        <div className="flex items-center gap-2.5">
          {session?.user?.image && (
            <img src={session.user.image} alt="" className="w-7 h-7 rounded-full border border-surface-border" />
          )}
          <span className="text-sm text-slate-400">{session?.user?.name?.split(' ')[0]}</span>
        </div>
      </div>
    </header>
  )
}
