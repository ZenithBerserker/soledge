// apps/web/src/components/dashboard/RecentSignalsFeed.tsx
import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'

interface Token {
  id: string
  mintAddress: string
  symbol: string | null
  name: string | null
  safetyScore: number
  compositeScore: number
  recommendation: string
  initialLiqUsd: number
  isRug: boolean
  isBundled: boolean
  launchedAt: Date
  mintAuthNull: boolean
  freezeAuthNull: boolean
  lpLocked: boolean
  top10Pct: number | null
}

export function RecentSignalsFeed({ tokens }: { tokens: Token[] }) {
  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-bg-border">
        <div className="flex items-center gap-2">
          <span className="live-dot"><span className="live-dot-inner" /></span>
          <h2 className="font-display font-semibold text-sm text-text-primary">Live Signal Feed</h2>
        </div>
        <Link href="/dashboard/signals" className="text-xs text-text-muted hover:text-accent-green transition-colors font-mono">
          VIEW ALL →
        </Link>
      </div>

      <div className="divide-y divide-bg-border">
        {tokens.length === 0 && (
          <div className="px-4 py-8 text-center text-text-muted text-sm">
            No tokens scanned yet. Engine starting up...
          </div>
        )}
        {tokens.map(token => (
          <TokenRow key={token.id} token={token} />
        ))}
      </div>
    </div>
  )
}

function TokenRow({ token }: { token: Token }) {
  const rec = token.recommendation as 'BUY' | 'WATCH' | 'SKIP' | 'RUG'
  const badgeClass = {
    BUY: 'badge-buy',
    WATCH: 'badge-watch',
    SKIP: 'badge-skip',
    RUG: 'badge-rug',
  }[rec]

  const scoreColor =
    token.compositeScore >= 75 ? 'text-accent-green' :
    token.compositeScore >= 50 ? 'text-accent-yellow' :
    'text-accent-red'

  const safetyCells = [
    { key: 'mint', ok: token.mintAuthNull, label: 'MINT' },
    { key: 'freeze', ok: token.freezeAuthNull, label: 'FREEZE' },
    { key: 'lp', ok: token.lpLocked, label: 'LP' },
    { key: 'conc', ok: (token.top10Pct ?? 100) < 30, label: 'CONC' },
  ]

  return (
    <div className="px-4 py-3 hover:bg-bg-secondary/50 transition-colors animate-slide-in">
      <div className="flex items-center gap-3">
        {/* Score */}
        <div className="flex-shrink-0 w-10 text-center">
          <div className={`font-mono font-bold text-sm ${scoreColor}`}>{token.compositeScore}</div>
          <div className="text-text-muted text-[10px]">score</div>
        </div>

        {/* Token info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="font-display font-semibold text-sm text-text-primary truncate">
              {token.symbol ? `$${token.symbol}` : token.mintAddress.slice(0,8) + '...'}
            </span>
            <span className={badgeClass}>{rec}</span>
            {token.isBundled && <span className="text-[10px] font-mono bg-accent-yellow/10 text-accent-yellow border border-accent-yellow/20 px-1.5 py-0.5 rounded">BUNDLED</span>}
          </div>
          <div className="flex items-center gap-3 text-[11px] text-text-muted font-mono">
            <span>💧 ${formatNum(token.initialLiqUsd)}</span>
            {safetyCells.map(c => (
              <span key={c.key} className={c.ok ? 'text-accent-green' : 'text-accent-red'}>
                {c.ok ? '✓' : '✗'}{c.label}
              </span>
            ))}
          </div>
        </div>

        {/* Time + links */}
        <div className="flex-shrink-0 text-right">
          <div className="text-[11px] text-text-muted mb-1">
            {formatDistanceToNow(new Date(token.launchedAt), { addSuffix: true })}
          </div>
          <div className="flex items-center gap-1.5">
            <a
              href={`https://dexscreener.com/solana/${token.mintAddress}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10px] text-text-muted hover:text-accent-green transition-colors font-mono"
            >
              DEX↗
            </a>
            <a
              href={`https://birdeye.so/token/${token.mintAddress}?chain=solana`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10px] text-text-muted hover:text-accent-blue transition-colors font-mono"
            >
              BIRD↗
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

function formatNum(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000)     return `${(n / 1_000).toFixed(0)}K`
  return n.toFixed(0)
}
