'use client'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { useEffect, useState } from 'react'

interface JitoData {
  live: { p25: number; p50: number; p75: number; p95: number; p99: number } | null
  history: Array<{ p25: number; p50: number; p75: number; p95: number; p99: number; createdAt: string }>
}

const toSOL = (lamports: number) => (lamports / 1e9).toFixed(6)

export function JitoChart() {
  const [data, setData] = useState<JitoData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/jito-metrics')
      .then(r => r.json())
      .then(r => { setData(r.data); setLoading(false) })
      .catch(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="card p-6 h-64 flex items-center justify-center">
      <div className="text-sm text-slate-500 font-mono animate-pulse">Loading Jito metrics...</div>
    </div>
  )

  const chartData = data?.history?.map(h => ({
    time: new Date(h.createdAt).toLocaleTimeString(),
    p50: +(h.p50 / 1e9 * 1000).toFixed(3),
    p75: +(h.p75 / 1e9 * 1000).toFixed(3),
    p95: +(h.p95 / 1e9 * 1000).toFixed(3),
  })) ?? []

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-display font-600 text-white">Jito Tip Floor</h3>
          <p className="text-xs text-slate-500 mt-0.5">Real-time landed tip percentiles (mSOL)</p>
        </div>
        {data?.live && (
          <div className="flex items-center gap-4 text-xs font-mono">
            <div><span className="text-slate-500">P50: </span><span className="text-white">{toSOL(data.live.p50)} SOL</span></div>
            <div><span className="text-slate-500">P75: </span><span className="text-brand">{toSOL(data.live.p75)} SOL</span></div>
            <div><span className="text-slate-500">P95: </span><span className="text-warn">{toSOL(data.live.p95)} SOL</span></div>
          </div>
        )}
      </div>

      {chartData.length > 0 ? (
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={chartData}>
            <XAxis dataKey="time" tick={{ fill: '#4a5568', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#4a5568', fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{ background: '#111116', border: '1px solid #1e1e26', borderRadius: 8, fontSize: 11 }}
              labelStyle={{ color: '#94a3b8' }}
            />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Line type="monotone" dataKey="p50" stroke="#64748b" dot={false} strokeWidth={1.5} name="P50" />
            <Line type="monotone" dataKey="p75" stroke="#00ff88" dot={false} strokeWidth={1.5} name="P75" />
            <Line type="monotone" dataKey="p95" stroke="#f59e0b" dot={false} strokeWidth={1.5} name="P95" />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <div className="h-48 flex items-center justify-center text-slate-600 text-sm font-mono">
          No historical data yet. Engine must be running to collect snapshots.
        </div>
      )}

      {data?.live && (
        <div className="mt-4 grid grid-cols-5 gap-2">
          {(['p25','p50','p75','p95','p99'] as const).map(k => (
            <div key={k} className="bg-surface rounded p-2 text-center">
              <div className="text-[10px] text-slate-600 font-mono">{k.toUpperCase()}</div>
              <div className="text-xs font-mono text-white">{toSOL(data.live![k])}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
