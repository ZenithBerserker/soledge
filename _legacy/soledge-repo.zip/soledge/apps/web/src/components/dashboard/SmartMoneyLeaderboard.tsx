// apps/web/src/components/dashboard/SmartMoneyLeaderboard.tsx
import Link from 'next/link'

interface Wallet {
  id: string
  address: string
  label: string | null
  category: string
  trustScore: number
  winRate: number
  totalPnlUsd: number
  totalTrades: number
  tags: string[]
}

export function SmartMoneyLeaderboard({ wallets }: { wallets: Wallet[] }) {
  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-bg-border">
        <h2 className="font-display font-semibold text-sm text-text-primary">🐋 Smart Money</h2>
        <Link href="/dashboard/smart-money" className="text-xs text-text-muted hover:text-accent-green transition-colors font-mono">
          VIEW ALL →
        </Link>
      </div>
      <div className="divide-y divide-bg-border">
        {wallets.length === 0 && (
          <div className="px-4 py-6 text-center text-text-muted text-xs">
            No wallets indexed yet
          </div>
        )}
        {wallets.map((w, i) => (
          <div key={w.id} className="px-4 py-2.5 hover:bg-bg-secondary/50 transition-colors">
            <div className="flex items-center gap-2.5">
              <span className="text-text-muted text-xs font-mono w-4 text-right">{i + 1}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-text-primary truncate">
                  {w.label ?? `${w.address.slice(0,8)}...`}
                </div>
                <div className="flex items-center gap-2 text-[11px] text-text-muted font-mono">
                  <span className="text-accent-green">{w.winRate.toFixed(0)}% win</span>
                  <span>+${formatNum(w.totalPnlUsd)}</span>
                </div>
              </div>
              <div className="flex-shrink-0 text-right">
                <div className="text-xs font-mono text-text-muted">{w.category}</div>
                <div className="text-xs font-bold text-accent-blue">{w.trustScore}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function formatNum(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000)     return `${(n / 1_000).toFixed(0)}K`
  return n.toFixed(0)
}
