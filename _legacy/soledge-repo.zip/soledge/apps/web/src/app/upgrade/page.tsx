'use client'
import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Check, Zap, Crown } from 'lucide-react'
import Link from 'next/link'
import { cn } from '@/lib/utils'

const PLANS = [
  {
    name: 'Free',
    price: 0,
    icon: null,
    color: 'border-surface-border',
    btnClass: 'bg-surface-hover text-slate-400 border border-surface-border cursor-default',
    btnLabel: 'Current Plan',
    key: null,
    features: [
      '5 alerts/day',
      '3 smart wallets',
      'Public rug/scam alerts',
      'Basic dashboard',
    ],
    missing: ['Alpha signals', 'Telegram/Discord alerts', 'Backtest access', 'API access'],
  },
  {
    name: 'Pro',
    price: 49,
    icon: Zap,
    color: 'border-brand/30',
    btnClass: 'bg-brand text-black font-semibold hover:bg-brand-dim glow-brand',
    btnLabel: 'Upgrade to Pro',
    key: 'PRO',
    features: [
      '100 alerts/day',
      '12 smart wallets',
      '10,000 API calls/mo',
      'Alpha signals (BUY/WATCH)',
      'Discord + Telegram alerts',
      'Backtest engine access',
      'Deployer reputation lookup',
    ],
    missing: ['Raw API access', 'Priority Jito tips'],
  },
  {
    name: 'Elite',
    price: 199,
    icon: Crown,
    color: 'border-warn/30',
    btnClass: 'bg-warn text-black font-semibold hover:opacity-90',
    btnLabel: 'Upgrade to Elite',
    key: 'ELITE',
    features: [
      'Unlimited alerts',
      'Unlimited smart wallets',
      'Unlimited API calls',
      'Raw JSON API access',
      'Priority Jito bundle tips',
      'Full deployer database',
      'Earliest alpha signals',
      'Dedicated support',
    ],
    missing: [],
  },
]

export default function UpgradePage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState<string | null>(null)

  async function handleUpgrade(plan: string) {
    if (!session) { router.push('/auth/signin'); return }
    setLoading(plan)
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan }),
      })
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch {
      alert('Something went wrong. Please try again.')
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="min-h-screen bg-surface">
      <div className="fixed inset-0 bg-grid-pattern bg-grid opacity-100 pointer-events-none" />
      <div className="fixed inset-0 bg-radial-brand pointer-events-none" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 py-20">
        {/* Header */}
        <div className="text-center mb-14">
          <Link href="/" className="text-sm text-slate-500 hover:text-slate-300 transition-colors mb-8 inline-block">← Back</Link>
          <h1 className="font-display text-4xl font-700 text-white mb-3">Choose your edge</h1>
          <p className="text-slate-400">Transparent pricing. No hidden fees. Cancel anytime.</p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={cn('card p-6 flex flex-col border', plan.color, plan.name === 'Pro' && 'ring-1 ring-brand/20')}
            >
              {plan.name === 'Pro' && (
                <div className="text-xs font-mono text-brand border border-brand/30 bg-brand/5 rounded px-2 py-1 mb-4 inline-block self-start">
                  MOST POPULAR
                </div>
              )}

              <div className="flex items-center gap-2 mb-1">
                {plan.icon && <plan.icon className={cn('w-4 h-4', plan.name === 'Pro' ? 'text-brand' : 'text-warn')} />}
                <span className="font-display font-600 text-white">{plan.name}</span>
              </div>

              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-3xl font-mono font-bold text-white">${plan.price}</span>
                <span className="text-slate-500 text-sm">/month</span>
              </div>

              <ul className="space-y-2.5 flex-1 mb-6">
                {plan.features.map(f => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-brand shrink-0 mt-0.5" />
                    <span className="text-slate-300">{f}</span>
                  </li>
                ))}
                {plan.missing.map(f => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <span className="w-4 h-4 shrink-0 mt-0.5 text-center text-slate-700">—</span>
                    <span className="text-slate-600 line-through">{f}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => plan.key && handleUpgrade(plan.key)}
                disabled={!plan.key || loading === plan.key}
                className={cn('w-full py-3 rounded-xl text-sm transition-all', plan.btnClass)}
              >
                {loading === plan.key ? 'Redirecting...' : plan.btnLabel}
              </button>
            </div>
          ))}
        </div>

        <p className="text-center text-xs text-slate-600 mt-10">
          Payments processed by Stripe. Subscriptions renew monthly. Cancel anytime from your dashboard.
          Not financial advice — trade responsibly.
        </p>
      </div>
    </div>
  )
}
