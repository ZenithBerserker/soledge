import { TopBar } from '@/components/dashboard/TopBar'
import { prisma } from '@soledge/db'
import { cn, truncate, formatUsd, scoreColor } from '@/lib/utils'
import { ExternalLink } from 'lucide-react'

export const dynamic = 'force-dynamic'

async function getTokens() {
  return prisma.tokenLaunch.findMany({
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: { _count: { select: { smartMoneyBuys: true } } },
  })
}

export default async function TokensPage() {
  const tokens = await getTokens()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Tokens" />
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-slate-400">{tokens.length} tokens indexed</p>
        </div>
        <div className="card overflow-hidden">
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="border-b border-surface-border text-slate-500">
                <th className="px-5 py-3 text-left">Token</th>
                <th className="px-4 py-3 text-right">Score</th>
                <th className="px-4 py-3 text-center">Mint✓</th>
                <th className="px-4 py-3 text-center">Freeze✓</th>
                <th className="px-4 py-3 text-center">LP✓</th>
                <th className="px-4 py-3 text-right">Top10%</th>
                <th className="px-4 py-3 text-right">Liq</th>
                <th className="px-4 py-3 text-right">Smart$</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-right">Links</th>
              </tr>
            </thead>
            <tbody>
              {tokens.length === 0 ? (
                <tr><td colSpan={10} className="px-5 py-12 text-center text-slate-600">No tokens indexed yet.</td></tr>
              ) : tokens.map(t => (
                <tr key={t.id} className="border-b border-surface-border/40 hover:bg-surface-hover transition-colors">
                  <td className="px-5 py-3">
                    <div className="text-white">${t.symbol ?? '???'}</div>
                    <div className="text-slate-600">{truncate(t.mintAddress, 6, 6)}</div>
                  </td>
                  <td className={cn('px-4 py-3 text-right', scoreColor(t.safetyScore))}>{t.safetyScore}</td>
                  <td className="px-4 py-3 text-center">{t.mintAuthNull ? '✅' : '❌'}</td>
                  <td className="px-4 py-3 text-center">{t.freezeAuthNull ? '✅' : '❌'}</td>
                  <td className="px-4 py-3 text-center">{t.lpLocked ? '✅' : '❌'}</td>
                  <td className={cn('px-4 py-3 text-right', (t.top10Pct ?? 100) < 30 ? 'text-brand' : (t.top10Pct ?? 100) < 50 ? 'text-warn' : 'text-danger')}>
                    {t.top10Pct?.toFixed(1) ?? '—'}%
                  </td>
                  <td className="px-4 py-3 text-right text-slate-300">{t.initialLiqUsd ? formatUsd(t.initialLiqUsd) : '—'}</td>
                  <td className="px-4 py-3 text-right text-info">{t._count.smartMoneyBuys}</td>
                  <td className="px-4 py-3 text-center">
                    {t.isRug ? (
                      <span className="text-danger">RUG</span>
                    ) : t.isHoneypot ? (
                      <span className="text-warn">HONEY</span>
                    ) : t.isBundled ? (
                      <span className="text-warn">BUNDLED</span>
                    ) : (
                      <span className="text-brand">CLEAN</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <a
                      href={`https://dexscreener.com/solana/${t.mintAddress}`}
                      target="_blank" rel="noopener noreferrer"
                      className="text-slate-500 hover:text-brand transition-colors inline-flex items-center gap-1"
                    >
                      DEX <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
