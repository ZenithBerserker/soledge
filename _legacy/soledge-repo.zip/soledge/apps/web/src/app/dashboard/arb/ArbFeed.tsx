'use client'
import { useState, useEffect, useCallback, useRef } from 'react'
import { TopBar } from '@/components/dashboard/TopBar'
import { Target, Zap, RefreshCw, Copy, Check, Play, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Opportunity {
  id: string
  pairs: string[]
  tokenPair: string
  entryAmountLabel: string
  projectedReturnX: number
  projectedReturnUsd: number
  projectedProfitUsd: number
  routeSteps: string[]
  jitoTipSol: number
  confidenceLevel: string
  poolLiquidityUsd: number
  slippagePct: number
  status: string
  detectedAt: string
  expiresAt: string | null
  poolAddress: string | null
}

interface HealthData {
  ok: boolean
  db: boolean
  tableReady: boolean
  opportunities: { total: number; live: number }
  secretConfigured: boolean
}

const CONFIDENCE_STYLES: Record<string, string> = {
  HIGH:   'text-brand border-brand/40 bg-brand/10',
  MEDIUM: 'text-warn border-warn/40 bg-warn/10',
  LOW:    'text-slate-400 border-slate-600 bg-slate-800/40',
}

const STATUS_STYLES: Record<string, string> = {
  LIVE:     'text-brand',
  EXPIRED:  'text-slate-600',
  EXECUTED: 'text-info',
  MISSED:   'text-danger',
}

function timeAgo(date: string): string {
  const s = Math.floor((Date.now() - new Date(date).getTime()) / 1000)
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  return `${Math.floor(s / 3600)}h ago`
}

function expiresIn(date: string | null): string {
  if (!date) return '—'
  const ms = new Date(date).getTime() - Date.now()
  if (ms <= 0) return 'expired'
  const s = Math.floor(ms / 1000)
  if (s < 60) return `${s}s`
  return `${Math.floor(s / 60)}m`
}

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false)
  function copy() {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button
      onClick={copy}
      className="flex items-center gap-1.5 text-xs font-mono px-2 py-1 rounded border border-surface-border text-slate-500 hover:text-brand hover:border-brand/30 transition-all shrink-0"
    >
      {copied ? <Check className="w-3 h-3 text-brand" /> : <Copy className="w-3 h-3" />}
      {label ?? (copied ? 'Copied!' : 'Copy')}
    </button>
  )
}

function OppCard({ opp }: { opp: Opportunity }) {
  const isLive = opp.status === 'LIVE'
  return (
    <div className={cn(
      'card p-5 transition-all border',
      isLive && opp.confidenceLevel === 'HIGH' ? 'border-brand/30 bg-brand/[0.03]' :
      isLive ? 'border-surface-border hover:border-surface-border/80' :
      'border-surface-border/40 opacity-60'
    )}>
      <div className="flex items-start gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className={cn('text-xs font-mono px-2 py-0.5 rounded border shrink-0', CONFIDENCE_STYLES[opp.confidenceLevel] ?? CONFIDENCE_STYLES.LOW)}>
              {opp.confidenceLevel}
            </span>
            {isLive
              ? <span className="flex items-center gap-1 text-xs font-mono text-brand"><span className="w-1.5 h-1.5 rounded-full bg-brand blink inline-block" />LIVE</span>
              : <span className={cn('text-xs font-mono', STATUS_STYLES[opp.status])}>{opp.status}</span>
            }
            <span className="ml-auto text-xs font-mono text-slate-600 shrink-0">{timeAgo(opp.detectedAt)}</span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap mb-3">
            {(opp.routeSteps.length > 0 ? opp.routeSteps : opp.pairs).map((step, i, arr) => (
              <span key={i} className="flex items-center gap-1.5">
                <span className="text-xs font-mono bg-surface px-2 py-0.5 rounded text-slate-300 border border-surface-border">{step}</span>
                {i < arr.length - 1 && <Zap className="w-2.5 h-2.5 text-brand/40 shrink-0" />}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-4 text-xs font-mono flex-wrap">
            <span><span className="text-slate-500">Entry: </span><span className="text-slate-300">{opp.entryAmountLabel}</span></span>
            {opp.poolLiquidityUsd > 0 && <span><span className="text-slate-500">Pool: </span><span className="text-slate-300">${opp.poolLiquidityUsd >= 1000 ? `${(opp.poolLiquidityUsd/1000).toFixed(1)}k` : opp.poolLiquidityUsd.toFixed(0)}</span></span>}
            {opp.slippagePct > 0 && <span><span className="text-slate-500">Slip: </span><span className={opp.slippagePct > 15 ? 'text-warn' : 'text-slate-300'}>{opp.slippagePct.toFixed(1)}%</span></span>}
            <span><span className="text-slate-500">Tip: </span><span className="text-slate-300">{opp.jitoTipSol} SOL</span></span>
            {isLive && opp.expiresAt && <span><span className="text-slate-500">Exp: </span><span className={expiresIn(opp.expiresAt) === 'expired' ? 'text-danger' : 'text-warn'}>{expiresIn(opp.expiresAt)}</span></span>}
          </div>

          {opp.poolAddress && (
            <div className="mt-2 flex items-center gap-2">
              <span className="text-[10px] font-mono text-slate-700 truncate">{opp.poolAddress.slice(0,16)}…{opp.poolAddress.slice(-8)}</span>
              <CopyButton text={opp.poolAddress} label="addr" />
            </div>
          )}
        </div>

        <div className="shrink-0 text-right">
          <div className={cn('text-3xl font-mono font-bold leading-none mb-1',
            opp.projectedReturnX >= 100 ? 'text-brand' : opp.projectedReturnX >= 10 ? 'text-warn' : 'text-slate-300')}>
            {opp.projectedReturnX >= 1000 ? `${(opp.projectedReturnX/1000).toFixed(1)}kx` : `${opp.projectedReturnX.toFixed(opp.projectedReturnX >= 10 ? 0 : 1)}x`}
          </div>
          <div className="text-xs font-mono text-slate-400">${opp.projectedReturnUsd.toFixed(0)} out</div>
          {opp.projectedProfitUsd > 0 && <div className="text-xs font-mono text-brand/70 mt-0.5">+${opp.projectedProfitUsd.toFixed(0)} profit</div>}
        </div>
      </div>
    </div>
  )
}

function DiagnosticPanel({ health, onRunMigration }: { health: HealthData | null; onRunMigration: () => void }) {
  const allGood = health?.db && health?.tableReady && health?.secretConfigured
  if (allGood) return null

  return (
    <div className="card border-warn/20 bg-warn/5 p-5 space-y-3">
      <div className="flex items-center gap-2">
        <AlertCircle className="w-4 h-4 text-warn shrink-0" />
        <span className="font-display font-600 text-warn text-sm">Setup required</span>
      </div>
      <div className="space-y-2 text-xs font-mono">
        <CheckRow ok={health?.db ?? false} label="Database connection" fix="Set DATABASE_URL in Vercel → Settings → Environment Variables" />
        <CheckRow ok={health?.tableReady ?? false} label="ArbOpportunity table exists" fix={null}>
          {!health?.tableReady && (
            <button
              onClick={onRunMigration}
              className="ml-2 px-2.5 py-1 bg-warn/20 border border-warn/40 text-warn rounded text-xs hover:bg-warn/30 transition-all"
            >
              Run migration →
            </button>
          )}
        </CheckRow>
        <CheckRow ok={health?.secretConfigured ?? false} label="ENGINE_INGEST_SECRET set" fix="Add ENGINE_INGEST_SECRET to Vercel env vars, then redeploy" />
      </div>
    </div>
  )
}

function CheckRow({ ok, label, fix, children }: { ok: boolean; label: string; fix: string | null; children?: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2">
      {ok
        ? <CheckCircle2 className="w-3.5 h-3.5 text-brand shrink-0 mt-0.5" />
        : <AlertCircle className="w-3.5 h-3.5 text-warn shrink-0 mt-0.5" />
      }
      <div className="flex-1">
        <span className={ok ? 'text-slate-400' : 'text-slate-300'}>{label}</span>
        {!ok && fix && <div className="text-slate-600 mt-0.5">{fix}</div>}
        {children}
      </div>
    </div>
  )
}

export function ArbFeed({ initialLive, initialRecent, liveCount, totalCount, expiredCount }: {
  initialLive: Opportunity[]
  initialRecent: Opportunity[]
  liveCount: number
  totalCount: number
  expiredCount: number
}) {
  const [live, setLive] = useState(initialLive)
  const [recent, setRecent] = useState(initialRecent)
  const [tab, setTab] = useState<'live' | 'recent'>('live')
  const [refreshing, setRefreshing] = useState(false)
  const [lastRefresh, setLastRefresh] = useState(Date.now())
  const [health, setHealth] = useState<HealthData | null>(null)
  const [testStatus, setTestStatus] = useState<'idle' | 'loading' | 'ok' | 'error'>('idle')
  const [testMsg, setTestMsg] = useState('')
  const [secretInput, setSecretInput] = useState('')
  const curlRef = useRef<HTMLPreElement>(null)

  // Check health on mount
  useEffect(() => {
    fetch('/api/health').then(r => r.json()).then(setHealth).catch(() => {})
  }, [])

  const refresh = useCallback(async () => {
    setRefreshing(true)
    try {
      const [h, liveRes, recentRes] = await Promise.all([
        fetch('/api/health').then(r => r.json()),
        fetch('/api/opportunities?status=LIVE&limit=50').then(r => r.json()),
        fetch('/api/opportunities?status=ALL&limit=30').then(r => r.json()),
      ])
      setHealth(h)
      if (liveRes.success) setLive(liveRes.data.filter((o: Opportunity) => o.status === 'LIVE'))
      if (recentRes.success) setRecent(recentRes.data.filter((o: Opportunity) => o.status !== 'LIVE'))
      setLastRefresh(Date.now())
    } catch {}
    setRefreshing(false)
  }, [])

  useEffect(() => {
    const id = setInterval(refresh, 10_000)
    return () => clearInterval(id)
  }, [refresh])

  async function runMigration() {
    setTestStatus('loading')
    setTestMsg('Running /api/migrate …')
    try {
      const r = await fetch('/api/migrate', { method: 'POST', headers: { 'x-engine-secret': secretInput } })
      const j = await r.json()
      if (j.success) {
        setTestStatus('ok')
        setTestMsg('Migration complete — table created!')
        refresh()
      } else {
        setTestStatus('error')
        setTestMsg(j.error ?? 'Migration failed')
      }
    } catch (e: any) {
      setTestStatus('error')
      setTestMsg(e.message)
    }
  }

  async function sendTestPayload() {
    if (!secretInput.trim()) {
      setTestStatus('error')
      setTestMsg('Enter your ENGINE_INGEST_SECRET first')
      return
    }
    setTestStatus('loading')
    setTestMsg('Sending test opportunity …')
    const payload = {
      id: `test-${Date.now()}`,
      detectedAt: new Date().toISOString(),
      pairs: ['SOL/USDC', 'BONK/SOL'],
      entryAmountLabel: '1 USDC',
      entryAmountSol: 0.007,
      projectedReturnX: 1200,
      projectedReturnUsd: 1200,
      projectedProfitUsd: 1199,
      routeSteps: ['USDC → SOL', 'SOL → BONK (Meteora)', 'BONK → USDC'],
      jitoTipSol: 0.5,
      confidenceLevel: 'HIGH',
      poolLiquidityUsd: 8500,
      slippagePct: 2.1,
      ttlSeconds: 60,
    }
    try {
      const r = await fetch('/api/opportunities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-engine-secret': secretInput },
        body: JSON.stringify(payload),
      })
      const j = await r.json()
      if (r.ok && j.success) {
        setTestStatus('ok')
        setTestMsg(`✓ Opportunity created (id: ${j.id})`)
        setTimeout(() => { refresh(); setTab('live') }, 800)
      } else {
        setTestStatus('error')
        setTestMsg(j.error ?? `HTTP ${r.status}`)
      }
    } catch (e: any) {
      setTestStatus('error')
      setTestMsg(e.message)
    }
  }

  const shown = tab === 'live' ? live : recent

  const sampleCurl = `curl -sS -X POST "https://YOUR_PROJECT.vercel.app/api/opportunities" \\
  -H "Content-Type: application/json" \\
  -H "x-engine-secret: YOUR_ENGINE_INGEST_SECRET" \\
  -d '{"pairs":["SOL/USDC","BONK/SOL"],"entryAmountLabel":"1 USDC","projectedReturnX":1200,"projectedReturnUsd":1200,"routeSteps":["USDC → SOL","SOL → BONK","BONK → USDC"],"jitoTipSol":0.5,"confidenceLevel":"HIGH","poolLiquidityUsd":8500,"ttlSeconds":30}'`

  const hasOpps = shown.length > 0

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Meteora DLMM scanner feed" />
      <div className="p-6 space-y-5 max-w-4xl">

        {/* Description */}
        <p className="text-sm text-slate-400 leading-relaxed">
          Monitors Meteora-style DLMM routes for large quoted edges (worker-side); small clips, slippage caps,
          and sim before live execution still apply. The worker POSTs JSON to{' '}
          <code className="text-brand font-mono text-xs bg-brand/10 px-1.5 py-0.5 rounded">/api/opportunities</code>
          {' '}(<code className="font-mono text-xs text-slate-300">x-engine-secret</code> or{' '}
          <code className="font-mono text-xs text-slate-300">Authorization: Bearer …</code>).
          In Vercel set <code className="font-mono text-xs text-slate-300">DATABASE_URL</code> and{' '}
          <code className="font-mono text-xs text-slate-300">ENGINE_INGEST_SECRET</code>. Check{' '}
          <a href="/api/health" target="_blank" className="text-brand hover:underline font-mono text-xs">/api/health</a>.
        </p>

        {/* Diagnostic panel */}
        <DiagnosticPanel health={health} onRunMigration={runMigration} />

        {/* Stats + refresh */}
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className={cn('w-2 h-2 rounded-full', live.length > 0 ? 'bg-brand blink' : 'bg-slate-700')} />
            <span className="text-slate-500">Live:</span>
            <span className={live.length > 0 ? 'text-brand' : 'text-slate-600'}>{live.length}</span>
          </div>
          <div><span className="text-slate-500">Total: </span><span className="text-slate-400">{totalCount + live.length}</span></div>
          <button onClick={refresh} disabled={refreshing} className="ml-auto flex items-center gap-1.5 text-slate-500 hover:text-brand transition-colors">
            <RefreshCw className={cn('w-3 h-3', refreshing && 'animate-spin')} />
            {refreshing ? 'Refreshing…' : `${Math.floor((Date.now() - lastRefresh) / 1000)}s ago`}
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-surface-border">
          {(['live', 'recent'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)} className={cn(
              'px-4 py-2 text-xs font-mono border-b-2 -mb-px transition-colors capitalize',
              tab === t ? 'border-brand text-brand' : 'border-transparent text-slate-500 hover:text-slate-300'
            )}>
              {t === 'live' ? `Live (${live.length})` : `Recent (${recent.length})`}
            </button>
          ))}
        </div>

        {/* Content */}
        {hasOpps ? (
          <div className="space-y-3">
            {shown.map(opp => <OppCard key={opp.id} opp={opp} />)}
          </div>
        ) : (
          <div className="card-glow rounded-xl p-6 space-y-5">
            <div>
              <h3 className="font-display font-600 text-brand mb-1">Database connected — no opportunities yet</h3>
              <p className="text-sm text-slate-400">
                Run the worker with real <code className="font-mono text-xs text-slate-300">POOL_A</code> /{' '}
                <code className="font-mono text-xs text-slate-300">POOL_B</code> /{' '}
                <code className="font-mono text-xs text-slate-300">START_MINT</code>, or POST a test payload:
              </p>
            </div>

            {/* In-browser test */}
            <div className="bg-surface rounded-xl border border-surface-border p-4 space-y-3">
              <div className="text-xs font-mono text-slate-400 flex items-center gap-2">
                <Play className="w-3.5 h-3.5 text-brand" />
                Test from browser — enter your <code className="text-slate-300">ENGINE_INGEST_SECRET</code>:
              </div>
              <div className="flex gap-2">
                <input
                  type="password"
                  value={secretInput}
                  onChange={e => setSecretInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && sendTestPayload()}
                  placeholder="ENGINE_INGEST_SECRET value from Vercel"
                  className="flex-1 bg-surface-raised border border-surface-border rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-700 focus:outline-none focus:border-brand/40"
                />
                <button
                  onClick={sendTestPayload}
                  disabled={testStatus === 'loading'}
                  className="px-4 py-2 bg-brand text-black text-xs font-semibold rounded-lg hover:bg-brand-dim transition-all disabled:opacity-40 flex items-center gap-1.5 shrink-0"
                >
                  {testStatus === 'loading'
                    ? <><Loader2 className="w-3 h-3 animate-spin" /> Sending…</>
                    : <><Play className="w-3 h-3" /> Send test</>
                  }
                </button>
              </div>
              {testMsg && (
                <div className={cn(
                  'text-xs font-mono px-3 py-2 rounded border',
                  testStatus === 'ok'    ? 'text-brand border-brand/30 bg-brand/5' :
                  testStatus === 'error' ? 'text-danger border-danger/30 bg-danger/5' :
                  'text-slate-400 border-surface-border'
                )}>
                  {testMsg}
                </div>
              )}
            </div>

            {/* curl command */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono text-slate-500">Or run from terminal:</span>
                <CopyButton text={sampleCurl} label="Copy curl" />
              </div>
              <pre
                ref={curlRef}
                className="bg-surface rounded-lg p-4 font-mono text-xs text-slate-300 border border-surface-border overflow-x-auto leading-relaxed whitespace-pre-wrap"
              >{sampleCurl}</pre>
            </div>

            {/* Payload schema */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-surface rounded-lg p-3 border border-surface-border">
                <div className="text-[10px] font-mono text-slate-600 mb-2 uppercase tracking-wider">Required fields</div>
                <div className="space-y-1 text-xs font-mono">
                  {[
                    ['pairs', 'string[]', 'e.g. ["SOL/USDC"]'],
                    ['projectedReturnX', 'number', 'min 2x'],
                    ['projectedReturnUsd', 'number', 'USD value out'],
                  ].map(([k, t, d]) => (
                    <div key={k} className="flex items-baseline gap-2">
                      <span className="text-brand w-32 shrink-0">{k}</span>
                      <span className="text-slate-500">{t}</span>
                      <span className="text-slate-700 text-[10px]">{d}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-surface rounded-lg p-3 border border-surface-border">
                <div className="text-[10px] font-mono text-slate-600 mb-2 uppercase tracking-wider">Optional fields</div>
                <div className="space-y-1 text-xs font-mono">
                  {[
                    ['routeSteps', 'string[]'],
                    ['jitoTipSol', 'number'],
                    ['confidenceLevel', 'HIGH|MEDIUM|LOW'],
                    ['poolLiquidityUsd', 'number'],
                    ['slippagePct', 'number (max 30)'],
                    ['ttlSeconds', 'number (default 30)'],
                  ].map(([k, t]) => (
                    <div key={k} className="flex items-baseline gap-2">
                      <span className="text-slate-400 w-32 shrink-0">{k}</span>
                      <span className="text-slate-600">{t}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
