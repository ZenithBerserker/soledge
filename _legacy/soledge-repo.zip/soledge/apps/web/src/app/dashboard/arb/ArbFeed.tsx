'use client'
import { useState, useEffect, useCallback } from 'react'
import { TopBar } from '@/components/dashboard/TopBar'
import { Target, Zap, Clock, CheckCircle, XCircle, RefreshCw, Copy, Check } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Opportunity {
  id: string
  pairs: string[]
  tokenPair: string
  entryAmountLabel: string
  projectedReturnX: number
  projectedReturnUsd: number
  projectedProfitUsd: number
  routeSteps: string[]
  jitoTipSol: number
  confidenceLevel: string
  poolLiquidityUsd: number
  slippagePct: number
  status: string
  detectedAt: string
  expiresAt: string | null
  poolAddress: string | null
}

interface ArbFeedProps {
  initialLive: Opportunity[]
  initialRecent: Opportunity[]
  liveCount: number
  totalCount: number
  expiredCount: number
}

const CONFIDENCE_STYLES: Record<string, string> = {
  HIGH:   'text-brand border-brand/40 bg-brand/10',
  MEDIUM: 'text-warn border-warn/40 bg-warn/10',
  LOW:    'text-slate-400 border-slate-600 bg-slate-800/40',
}

const STATUS_STYLES: Record<string, string> = {
  LIVE:     'text-brand',
  EXPIRED:  'text-slate-600',
  EXECUTED: 'text-info',
  MISSED:   'text-danger',
}

function timeAgo(date: string): string {
  const s = Math.floor((Date.now() - new Date(date).getTime()) / 1000)
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  return `${Math.floor(s / 3600)}h ago`
}

function expiresIn(date: string | null): string {
  if (!date) return '—'
  const ms = new Date(date).getTime() - Date.now()
  if (ms <= 0) return 'expired'
  const s = Math.floor(ms / 1000)
  if (s < 60) return `${s}s`
  return `${Math.floor(s / 60)}m`
}

function OppCard({ opp, dim = false }: { opp: Opportunity; dim?: boolean }) {
  const [copied, setCopied] = useState(false)

  function copy(text: string) {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const isLive = opp.status === 'LIVE'

  return (
    <div className={cn(
      'card p-5 transition-all border',
      isLive && opp.confidenceLevel === 'HIGH' ? 'border-brand/30 bg-brand/[0.03]' :
      isLive ? 'border-surface-border hover:border-surface-border/80' :
      'border-surface-border/40 opacity-60'
    )}>
      <div className="flex items-start gap-4">
        {/* Left: route + meta */}
        <div className="flex-1 min-w-0">
          {/* Header row */}
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className={cn(
              'text-xs font-mono px-2 py-0.5 rounded border shrink-0',
              CONFIDENCE_STYLES[opp.confidenceLevel] ?? CONFIDENCE_STYLES.LOW
            )}>
              {opp.confidenceLevel}
            </span>

            {isLive && (
              <span className="flex items-center gap-1 text-xs font-mono text-brand">
                <span className="w-1.5 h-1.5 rounded-full bg-brand blink inline-block" />
                LIVE
              </span>
            )}
            {!isLive && (
              <span className={cn('text-xs font-mono', STATUS_STYLES[opp.status])}>
                {opp.status}
              </span>
            )}

            <span className="ml-auto text-xs font-mono text-slate-600 shrink-0">
              {timeAgo(opp.detectedAt)}
            </span>
          </div>

          {/* Route steps */}
          <div className="flex items-center gap-1.5 flex-wrap mb-3">
            {opp.routeSteps.length > 0
              ? opp.routeSteps.map((step, i) => (
                  <span key={i} className="flex items-center gap-1.5">
                    <span className="text-xs font-mono bg-surface px-2 py-0.5 rounded text-slate-300 border border-surface-border">
                      {step}
                    </span>
                    {i < opp.routeSteps.length - 1 && (
                      <Zap className="w-2.5 h-2.5 text-brand/40 shrink-0" />
                    )}
                  </span>
                ))
              : opp.pairs.map((pair, i) => (
                  <span key={i} className="flex items-center gap-1.5">
                    <span className="text-xs font-mono bg-surface px-2 py-0.5 rounded text-slate-300 border border-surface-border">
                      {pair}
                    </span>
                    {i < opp.pairs.length - 1 && (
                      <Zap className="w-2.5 h-2.5 text-brand/40 shrink-0" />
                    )}
                  </span>
                ))
            }
          </div>

          {/* Stats row */}
          <div className="flex items-center gap-4 text-xs font-mono flex-wrap">
            <div>
              <span className="text-slate-500">Entry: </span>
              <span className="text-slate-300">{opp.entryAmountLabel}</span>
            </div>
            {opp.poolLiquidityUsd > 0 && (
              <div>
                <span className="text-slate-500">Pool liq: </span>
                <span className="text-slate-300">
                  ${opp.poolLiquidityUsd >= 1000
                    ? `${(opp.poolLiquidityUsd / 1000).toFixed(1)}k`
                    : opp.poolLiquidityUsd.toFixed(0)}
                </span>
              </div>
            )}
            {opp.slippagePct > 0 && (
              <div>
                <span className="text-slate-500">Slippage: </span>
                <span className={opp.slippagePct > 15 ? 'text-warn' : 'text-slate-300'}>
                  {opp.slippagePct.toFixed(1)}%
                </span>
              </div>
            )}
            <div>
              <span className="text-slate-500">Tip: </span>
              <span className="text-slate-300">{opp.jitoTipSol} SOL</span>
            </div>
            {isLive && opp.expiresAt && (
              <div>
                <span className="text-slate-500">Expires: </span>
                <span className={expiresIn(opp.expiresAt) === 'expired' ? 'text-danger' : 'text-warn'}>
                  {expiresIn(opp.expiresAt)}
                </span>
              </div>
            )}
          </div>

          {/* Pool address */}
          {opp.poolAddress && (
            <div className="mt-2.5 flex items-center gap-2">
              <span className="text-[10px] font-mono text-slate-700 truncate">
                {opp.poolAddress.slice(0, 16)}…{opp.poolAddress.slice(-8)}
              </span>
              <button
                onClick={() => copy(opp.poolAddress!)}
                className="text-[10px] text-slate-600 hover:text-brand transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-brand" /> : <Copy className="w-3 h-3" />}
              </button>
            </div>
          )}
        </div>

        {/* Right: return figure */}
        <div className="shrink-0 text-right">
          <div className={cn(
            'text-3xl font-mono font-bold leading-none mb-1',
            opp.projectedReturnX >= 100 ? 'text-brand' :
            opp.projectedReturnX >= 10  ? 'text-warn'  : 'text-slate-300'
          )}>
            {opp.projectedReturnX >= 1000
              ? `${(opp.projectedReturnX / 1000).toFixed(1)}kx`
              : `${opp.projectedReturnX.toFixed(opp.projectedReturnX >= 10 ? 0 : 1)}x`}
          </div>
          <div className="text-xs font-mono text-slate-400">
            ${opp.projectedReturnUsd.toFixed(0)} out
          </div>
          {opp.projectedProfitUsd > 0 && (
            <div className="text-xs font-mono text-brand/70 mt-0.5">
              +${opp.projectedProfitUsd.toFixed(0)} profit
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export function ArbFeed({ initialLive, initialRecent, liveCount, totalCount, expiredCount }: ArbFeedProps) {
  const [live, setLive] = useState(initialLive)
  const [recent, setRecent] = useState(initialRecent)
  const [tab, setTab] = useState<'live' | 'recent'>('live')
  const [refreshing, setRefreshing] = useState(false)
  const [lastRefresh, setLastRefresh] = useState(new Date())

  const refresh = useCallback(async () => {
    setRefreshing(true)
    try {
      const [liveRes, recentRes] = await Promise.all([
        fetch('/api/opportunities?status=LIVE&limit=50').then(r => r.json()),
        fetch('/api/opportunities?status=ALL&limit=30').then(r => r.json()),
      ])
      if (liveRes.success) setLive(liveRes.data.filter((o: Opportunity) => o.status === 'LIVE'))
      if (recentRes.success) setRecent(recentRes.data.filter((o: Opportunity) => o.status !== 'LIVE'))
      setLastRefresh(new Date())
    } catch {}
    setRefreshing(false)
  }, [])

  // Auto-refresh every 10s
  useEffect(() => {
    const id = setInterval(refresh, 10_000)
    return () => clearInterval(id)
  }, [refresh])

  const shown = tab === 'live' ? live : recent

  // Build the ingest curl command for the empty state
  const samplePayload = JSON.stringify({
    id: 'test-1',
    detectedAt: new Date().toISOString(),
    pairs: ['TEST/USDC'],
    entryAmountLabel: '1 USDC',
    projectedReturnX: 1200,
    projectedReturnUsd: 1200,
    projectedProfitUsd: 1199,
    routeSteps: ['USDC → TEST', 'TEST → USDC'],
    jitoTipSol: 0.5,
    confidenceLevel: 'HIGH',
    poolLiquidityUsd: 8000,
    slippagePct: 2.1,
    ttlSeconds: 30,
  })

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Meteora DLMM scanner feed" />

      <div className="p-6 space-y-5">
        {/* Description */}
        <p className="text-sm text-slate-400 max-w-3xl leading-relaxed">
          Monitors Meteora-style DLMM routes for large quoted edges (worker-side); small clips, slippage caps,
          and sim before live execution still apply. The worker POSTs JSON to{' '}
          <code className="text-brand font-mono text-xs bg-brand/10 px-1.5 py-0.5 rounded">/api/opportunities</code>
          {' '}(<code className="font-mono text-xs text-slate-400">x-engine-secret</code> or{' '}
          <code className="font-mono text-xs text-slate-400">Authorization: Bearer …</code>).
          In Vercel set <code className="font-mono text-xs text-slate-400">DATABASE_URL</code> (Neon or Supabase Postgres)
          and <code className="font-mono text-xs text-slate-400">ENGINE_INGEST_SECRET</code>. Check{' '}
          <a href="/api/health" target="_blank" className="text-brand hover:underline font-mono text-xs">/api/health</a>.
        </p>

        {/* Stats bar */}
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className={cn('w-2 h-2 rounded-full', live.length > 0 ? 'bg-brand blink' : 'bg-slate-700')} />
            <span className="text-slate-500">Live:</span>
            <span className={live.length > 0 ? 'text-brand' : 'text-slate-600'}>{live.length}</span>
          </div>
          <div>
            <span className="text-slate-500">Total: </span>
            <span className="text-slate-400">{totalCount}</span>
          </div>
          <div>
            <span className="text-slate-500">Expired: </span>
            <span className="text-slate-600">{expiredCount}</span>
          </div>
          <button
            onClick={refresh}
            disabled={refreshing}
            className="ml-auto flex items-center gap-1.5 text-slate-500 hover:text-brand transition-colors"
          >
            <RefreshCw className={cn('w-3 h-3', refreshing && 'animate-spin')} />
            {refreshing ? 'Refreshing…' : `Updated ${Math.floor((Date.now() - lastRefresh.getTime()) / 1000)}s ago`}
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-surface-border">
          {(['live', 'recent'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                'px-4 py-2 text-xs font-mono border-b-2 -mb-px transition-colors capitalize',
                tab === t
                  ? 'border-brand text-brand'
                  : 'border-transparent text-slate-500 hover:text-slate-300'
              )}
            >
              {t === 'live' ? `Live (${live.length})` : `Recent (${recent.length})`}
            </button>
          ))}
        </div>

        {/* Opportunities list or empty state */}
        {shown.length === 0 ? (
          <div className="card-glow p-7 rounded-xl">
            <div className="flex items-center gap-3 mb-3">
              <Target className="w-5 h-5 text-brand" />
              <h3 className="font-display font-600 text-brand">
                {tab === 'live' ? 'Database connected — no opportunities yet' : 'No recent opportunities'}
              </h3>
            </div>
            {tab === 'live' && (
              <>
                <p className="text-sm text-slate-400 mb-5">
                  Run the worker with real <code className="font-mono text-xs text-slate-300">POOL_A</code> /{' '}
                  <code className="font-mono text-xs text-slate-300">POOL_B</code> /{' '}
                  <code className="font-mono text-xs text-slate-300">START_MINT</code>, or POST a test payload (same secret as Vercel):
                </p>
                <div className="bg-surface rounded-lg p-4 font-mono text-xs overflow-x-auto border border-surface-border">
                  <div className="text-slate-500 mb-2"># Test the ingest endpoint</div>
                  <div className="text-slate-300 space-y-1 leading-relaxed">
                    <div>
                      <span className="text-brand">curl</span>
                      {' '}-sS -X POST &quot;https://YOUR_PROJECT.vercel.app/api/opportunities&quot; \
                    </div>
                    <div className="pl-4">-H &quot;Content-Type: application/json&quot; \</div>
                    <div className="pl-4">-H &quot;x-engine-secret: YOUR_ENGINE_INGEST_SECRET&quot; \</div>
                    <div className="pl-4">
                      -d &apos;{samplePayload.length > 120 ? samplePayload.slice(0, 120) + '…' : samplePayload}&apos;
                    </div>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3 text-xs font-mono">
                  <div className="bg-surface rounded-lg p-3 border border-surface-border">
                    <div className="text-slate-500 mb-1">Required Vercel env vars</div>
                    <div className="space-y-0.5 text-slate-400">
                      <div>DATABASE_URL=postgresql://…</div>
                      <div>ENGINE_INGEST_SECRET=…</div>
                    </div>
                  </div>
                  <div className="bg-surface rounded-lg p-3 border border-surface-border">
                    <div className="text-slate-500 mb-1">Payload schema</div>
                    <div className="space-y-0.5 text-slate-400">
                      <div><span className="text-brand">pairs</span>: string[]  <span className="text-slate-700">// required</span></div>
                      <div><span className="text-brand">projectedReturnX</span>: number</div>
                      <div><span className="text-brand">projectedReturnUsd</span>: number</div>
                      <div>confidenceLevel, jitoTipSol…</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {shown.map(opp => (
              <OppCard key={opp.id} opp={opp} dim={tab === 'recent'} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
