import { TopBar } from '@/components/dashboard/TopBar'
import { JitoChart } from '@/components/dashboard/JitoChart'
import { prisma } from '@soledge/db'
import { Zap } from 'lucide-react'

export const dynamic = 'force-dynamic'

async function getRecentSnaps() {
  return prisma.jitoMetricSnapshot.findMany({
    orderBy: { createdAt: 'desc' },
    take: 5,
  })
}

const toSOL = (l: number) => (l / 1e9).toFixed(6)

export default async function JitoPage() {
  const snaps = await getRecentSnaps()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Jito Metrics" />
      <div className="p-6 space-y-6">
        <JitoChart />

        {/* Recent snapshots table */}
        <div className="card">
          <div className="px-5 py-4 border-b border-surface-border">
            <h3 className="font-display font-600 text-white text-sm">Recent Snapshots</h3>
          </div>
          {snaps.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-600 font-mono">
              No snapshots yet. Engine persists a snapshot every minute.
            </div>
          ) : (
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-surface-border text-slate-500">
                  <th className="px-5 py-3 text-left">Time</th>
                  <th className="px-4 py-3 text-right">P25</th>
                  <th className="px-4 py-3 text-right">P50</th>
                  <th className="px-4 py-3 text-right text-brand">P75</th>
                  <th className="px-4 py-3 text-right text-warn">P95</th>
                  <th className="px-4 py-3 text-right text-danger">P99</th>
                </tr>
              </thead>
              <tbody>
                {snaps.map(s => (
                  <tr key={s.id} className="border-b border-surface-border/40 hover:bg-surface-hover transition-colors">
                    <td className="px-5 py-3 text-slate-400">{new Date(s.createdAt).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right text-slate-400">{toSOL(s.p25)}</td>
                    <td className="px-4 py-3 text-right text-slate-300">{toSOL(s.p50)}</td>
                    <td className="px-4 py-3 text-right text-brand">{toSOL(s.p75)}</td>
                    <td className="px-4 py-3 text-right text-warn">{toSOL(s.p95)}</td>
                    <td className="px-4 py-3 text-right text-danger">{toSOL(s.p99)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Bundle construction guide */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-4 h-4 text-brand" />
            <h3 className="font-display font-600 text-white text-sm">Tip Strategy Guide</h3>
          </div>
          <div className="grid grid-cols-3 gap-4 text-xs font-mono">
            {[
              { label: 'P75 — Standard', desc: 'Good for most trades. 75% of bundles at or below this tip land.', color: 'text-brand' },
              { label: 'P95 — Competitive', desc: 'Use during high-congestion periods or for time-sensitive entries.', color: 'text-warn' },
              { label: 'P99 — Aggressive', desc: 'For highest-priority MEV. Pay top-of-block to guarantee landing.', color: 'text-danger' },
            ].map(t => (
              <div key={t.label} className="bg-surface rounded-lg p-4">
                <div className={`${t.color} font-600 mb-1`}>{t.label}</div>
                <div className="text-slate-500 leading-relaxed">{t.desc}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 text-xs text-slate-600 font-mono leading-relaxed">
            💡 Tip goes in the <span className="text-brand">last transaction</span> of the bundle to prevent uncle-block theft.
            For single-tx: 70% priority fee + 30% Jito tip. For bundles: only tip matters for priority.
          </div>
        </div>
      </div>
    </div>
  )
}
