import { TopBar } from '@/components/dashboard/TopBar'
import { prisma } from '@soledge/db'
import { Wallet, TrendingUp, Award } from 'lucide-react'
import { truncate, formatUsd, cn } from '@/lib/utils'

export const dynamic = 'force-dynamic'

async function getWallets() {
  return prisma.smartWallet.findMany({
    orderBy: [{ trustScore: 'desc' }, { totalPnlUsd: 'desc' }],
    take: 50,
    include: { _count: { select: { activities: true } } },
  })
}

const CATEGORY_COLORS: Record<string, string> = {
  INSIDER: 'text-danger bg-danger/10 border-danger/20',
  ALPHA: 'text-brand bg-brand/10 border-brand/20',
  WHALE: 'text-info bg-info/10 border-info/20',
  DEV_WALLET: 'text-warn bg-warn/10 border-warn/20',
  BOT: 'text-slate-400 bg-slate-400/10 border-slate-400/20',
  FADE: 'text-purple-400 bg-purple-400/10 border-purple-400/20',
  UNKNOWN: 'text-slate-600 bg-slate-600/10 border-slate-600/20',
}

export default async function WalletsPage() {
  const wallets = await getWallets()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Smart Money" />
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm text-slate-400">{wallets.length} wallets tracked</p>
          <div className="text-xs font-mono text-slate-600">Sorted by trust score</div>
        </div>

        {wallets.length === 0 ? (
          <div className="card p-12 text-center">
            <Wallet className="w-10 h-10 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-500 font-mono text-sm">No wallets yet. Run db:seed to add starter wallets.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {wallets.map((w, i) => (
              <div key={w.id} className="card p-4 hover:border-surface-border/80 transition-all">
                <div className="flex items-center gap-4">
                  {/* Rank */}
                  <div className="w-7 text-xs font-mono text-slate-600 text-center shrink-0">#{i + 1}</div>

                  {/* Address */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-mono text-sm text-white">
                        {w.label ?? truncate(w.address, 6, 6)}
                      </span>
                      <span className={cn('text-[10px] font-mono px-1.5 py-0.5 rounded border', CATEGORY_COLORS[w.category])}>
                        {w.category}
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 font-mono">{truncate(w.address, 8, 8)}</div>
                  </div>

                  {/* Stats */}
                  <div className="flex items-center gap-6 text-xs font-mono shrink-0">
                    <div className="text-center">
                      <div className="text-slate-500">Win Rate</div>
                      <div className={w.winRate >= 70 ? 'text-brand' : w.winRate >= 50 ? 'text-warn' : 'text-danger'}>
                        {w.winRate.toFixed(0)}%
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-slate-500">PnL</div>
                      <div className={w.totalPnlUsd >= 0 ? 'text-brand' : 'text-danger'}>
                        {formatUsd(Math.abs(w.totalPnlUsd))}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-slate-500">Trades</div>
                      <div className="text-white">{w._count.activities}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-slate-500">Trust</div>
                      <div className={w.trustScore >= 70 ? 'text-brand' : w.trustScore >= 50 ? 'text-warn' : 'text-danger'}>
                        {w.trustScore}/100
                      </div>
                    </div>
                  </div>

                  {/* Trust bar */}
                  <div className="w-20 shrink-0">
                    <div className="h-1.5 bg-surface rounded-full overflow-hidden">
                      <div
                        className={cn('h-full rounded-full transition-all',
                          w.trustScore >= 70 ? 'bg-brand' : w.trustScore >= 50 ? 'bg-warn' : 'bg-danger'
                        )}
                        style={{ width: `${w.trustScore}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
