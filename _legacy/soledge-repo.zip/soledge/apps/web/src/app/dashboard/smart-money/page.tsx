// apps/web/src/app/dashboard/smart-money/page.tsx
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'
export const revalidate = 0

export default async function SmartMoneyPage() {
  const wallets = await prisma.smartWallet.findMany({
    orderBy: { totalPnlUsd: 'desc' },
    take: 50,
  })

  const recentActivity = await prisma.smartMoneyActivity.findMany({
    orderBy: { createdAt: 'desc' },
    take: 30,
    include: {
      wallet: { select: { label: true, category: true, trustScore: true } },
      token: { select: { symbol: true, mintAddress: true } },
    }
  })

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl text-text-primary">🐋 Smart Money Tracking</h1>
        <p className="text-text-secondary text-sm mt-1">
          {wallets.length} wallets tracked in real-time via Yellowstone gRPC
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        {/* Wallet leaderboard */}
        <div className="card overflow-hidden">
          <div className="px-5 py-3 border-b border-bg-border">
            <h2 className="font-display font-semibold text-sm">Top Profitable Wallets</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-text-muted text-xs font-mono uppercase border-b border-bg-border">
                  <th className="text-left px-5 py-2">#</th>
                  <th className="text-left px-3 py-2">Wallet</th>
                  <th className="text-right px-3 py-2">Win Rate</th>
                  <th className="text-right px-3 py-2">PnL</th>
                  <th className="text-right px-3 py-2">Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-bg-border">
                {wallets.length === 0 && (
                  <tr><td colSpan={5} className="px-5 py-8 text-center text-text-muted">No wallets indexed</td></tr>
                )}
                {wallets.map((w, i) => (
                  <tr key={w.id} className="hover:bg-bg-secondary/50 transition-colors">
                    <td className="px-5 py-2.5 text-text-muted font-mono text-xs">{i + 1}</td>
                    <td className="px-3 py-2.5">
                      <div className="text-text-primary text-sm font-medium">
                        {w.label ?? `${w.address.slice(0,8)}...`}
                      </div>
                      <div className="text-text-muted text-xs font-mono">{w.category} · {w.totalTrades} trades</div>
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <span className="font-mono font-bold text-accent-green">{w.winRate.toFixed(0)}%</span>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-text-secondary">
                      ${w.totalPnlUsd >= 1_000_000 ? (w.totalPnlUsd / 1_000_000).toFixed(1) + 'M' : (w.totalPnlUsd / 1000).toFixed(0) + 'K'}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <span className={`font-mono font-bold ${w.trustScore >= 80 ? 'text-accent-green' : w.trustScore >= 60 ? 'text-accent-yellow' : 'text-text-muted'}`}>
                        {w.trustScore}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent activity */}
        <div className="card overflow-hidden">
          <div className="flex items-center gap-2 px-5 py-3 border-b border-bg-border">
            <span className="live-dot"><span className="live-dot-inner" /></span>
            <h2 className="font-display font-semibold text-sm">Live Activity</h2>
          </div>
          <div className="divide-y divide-bg-border max-h-96 overflow-y-auto">
            {recentActivity.length === 0 && (
              <div className="px-5 py-8 text-center text-text-muted text-sm">No activity yet</div>
            )}
            {recentActivity.map(a => (
              <div key={a.id} className="px-4 py-2.5 flex items-center gap-3">
                <span className={`text-lg ${a.action === 'BUY' ? '🟢' : '🔴'}`} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-text-primary">
                    <span className="font-medium">{a.wallet.label ?? 'Wallet'}</span>
                    {' '}<span className={`font-bold ${a.action === 'BUY' ? 'text-accent-green' : 'text-accent-red'}`}>{a.action}</span>{' '}
                    <span className="text-text-secondary">${a.token.symbol ?? a.token.mintAddress.slice(0, 8)}</span>
                  </div>
                  <div className="text-text-muted text-xs font-mono">{a.amountSol.toFixed(3)} SOL · Score {a.wallet.trustScore}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
