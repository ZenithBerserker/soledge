// apps/web/src/app/dashboard/arb/page.tsx
import { prisma } from '@soledge/db'
import { ArbFeed } from './ArbFeed'

export const dynamic = 'force-dynamic'
export const revalidate = 0

async function getData() {
  // Auto-expire stale opportunities
  await prisma.arbOpportunity.updateMany({
    where: { status: 'LIVE', expiresAt: { lt: new Date() } },
    data: { status: 'EXPIRED' },
  }).catch(() => {})

  const [live, recent, stats] = await Promise.all([
    prisma.arbOpportunity.findMany({
      where: { status: 'LIVE' },
      orderBy: { detectedAt: 'desc' },
      take: 50,
    }),
    prisma.arbOpportunity.findMany({
      where: { status: { in: ['EXPIRED', 'EXECUTED', 'MISSED'] } },
      orderBy: { detectedAt: 'desc' },
      take: 30,
    }),
    prisma.arbOpportunity.groupBy({
      by: ['status'],
      _count: true,
    }),
  ])

  return { live, recent, stats }
}

export default async function ArbPage() {
  const { live, recent, stats } = await getData()

  const totalCount = stats.reduce((s, g) => s + g._count, 0)
  const liveCount = live.length
  const expiredCount = stats.find(g => g.status === 'EXPIRED')?._count ?? 0

  return (
    <ArbFeed
      initialLive={JSON.parse(JSON.stringify(live))}
      initialRecent={JSON.parse(JSON.stringify(recent))}
      liveCount={liveCount}
      totalCount={totalCount}
      expiredCount={expiredCount}
    />
  )
}
