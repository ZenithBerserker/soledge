import { TopBar } from '@/components/dashboard/TopBar'
import { prisma } from '@soledge/db'
import { cn, formatUsd } from '@/lib/utils'
import { Zap, Target } from 'lucide-react'

export const dynamic = 'force-dynamic'

async function getArbAlerts() {
  return prisma.alphaAlert.findMany({
    where: { title: { startsWith: '🎯 METEORA ARB' } },
    orderBy: { createdAt: 'desc' },
    take: 50,
  })
}

export default async function ArbPage() {
  const alerts = await getArbAlerts()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Meteora ARB" />
      <div className="p-6">
        {/* Info banner */}
        <div className="flex items-start gap-3 mb-6 p-4 rounded-xl border border-brand/20 bg-brand/5">
          <Target className="w-5 h-5 text-brand shrink-0 mt-0.5" />
          <div className="text-sm text-slate-300">
            <strong className="text-brand">Meteora DLMM Arbitrage Engine</strong> monitors all pools for extreme price imbalances. 
            Only opportunities with &gt;500x theoretical return, &lt;30% slippage, and max $50 input are surfaced.
            Opportunities are ELITE-tier only — execution speed is everything.
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-slate-400">{alerts.length} arb opportunities detected</p>
          <span className="text-xs font-mono text-slate-600">ELITE tier · max $50 input · Jito bundle execution</span>
        </div>

        {alerts.length === 0 ? (
          <div className="card p-12 text-center">
            <Target className="w-10 h-10 text-slate-700 mx-auto mb-3" />
            <p className="text-slate-500 font-mono text-sm">No arb opportunities yet.</p>
            <p className="text-slate-700 text-xs mt-2">Engine must be running and subscribed to Meteora DLMM pools.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {alerts.map(a => {
              const meta = a.metadata as any
              return (
                <div key={a.id} className={cn(
                  'card p-5 border-brand/15 hover:border-brand/30 transition-all',
                  meta?.confidenceLevel === 'HIGH' && 'border-brand/30 bg-brand/3'
                )}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className={cn(
                          'text-xs font-mono px-2 py-0.5 rounded border',
                          meta?.confidenceLevel === 'HIGH' ? 'text-brand border-brand/30 bg-brand/10' :
                          meta?.confidenceLevel === 'MEDIUM' ? 'text-warn border-warn/30 bg-warn/10' :
                          'text-slate-400 border-slate-700'
                        )}>
                          {meta?.confidenceLevel ?? 'UNKNOWN'}
                        </div>
                        <span className="font-mono text-sm font-600 text-white">{a.title}</span>
                        <span className="ml-auto text-xs font-mono text-slate-600">
                          {new Date(a.createdAt).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mb-3">{a.body}</p>

                      {meta?.routeSteps && (
                        <div className="flex items-center gap-2 flex-wrap">
                          {meta.routeSteps.map((step: string, i: number) => (
                            <span key={i} className="flex items-center gap-1.5">
                              <span className="text-xs font-mono bg-surface px-2 py-0.5 rounded text-slate-400">{step}</span>
                              {i < meta.routeSteps.length - 1 && <Zap className="w-3 h-3 text-brand/40" />}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="shrink-0 text-right text-xs font-mono">
                      <div className="text-2xl font-bold text-brand mb-1">
                        {meta?.projectedReturnX ? `${meta.projectedReturnX.toFixed(0)}x` : '—'}
                      </div>
                      <div className="text-slate-500">Input: ${meta?.estimatedInputUsdc?.toFixed(2) ?? '—'}</div>
                      <div className="text-brand/70">→ ${meta?.projectedReturnUsd?.toFixed(0) ?? '—'}</div>
                      <div className="text-slate-600 mt-1">Tip: {meta?.recommendedJitoTipSol} SOL</div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
