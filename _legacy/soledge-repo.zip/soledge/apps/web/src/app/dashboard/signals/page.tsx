import { TopBar } from '@/components/dashboard/TopBar'
import { SignalCard } from '@/components/dashboard/SignalCard'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

async function getSignals() {
  return prisma.alphaAlert.findMany({
    where: { type: 'ALPHA_SIGNAL' },
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: { token: { select: { mintAddress: true, symbol: true, safetyScore: true } } },
  })
}

export default async function SignalsPage() {
  const signals = await getSignals()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Alpha Signals" />
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-slate-400">{signals.length} signals</p>
          <div className="flex gap-2 text-xs font-mono">
            {['ALL','BUY','WATCH','SKIP'].map(f => (
              <button key={f} className="px-3 py-1.5 rounded border border-surface-border text-slate-400 hover:text-white hover:border-brand/30 transition-all">
                {f}
              </button>
            ))}
          </div>
        </div>
        {signals.length === 0 ? (
          <div className="card p-12 text-center">
            <p className="text-slate-500 font-mono">No signals yet. Start the engine to generate alpha signals.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {signals.map(s => <SignalCard key={s.id} alert={s as any} />)}
          </div>
        )}
      </div>
    </div>
  )
}
