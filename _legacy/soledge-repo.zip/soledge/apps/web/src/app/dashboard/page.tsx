import { TopBar } from '@/components/dashboard/TopBar'
import { StatCard } from '@/components/dashboard/StatCard'
import { LiveFeed } from '@/components/dashboard/LiveFeed'
import { JitoChart } from '@/components/dashboard/JitoChart'
import { prisma } from '@soledge/db'
import { Zap, Shield, Wallet, TrendingUp } from 'lucide-react'
import { formatUsd } from '@/lib/utils'

async function getStats() {
  const [tokens, rugCount, wallets, alerts] = await Promise.all([
    prisma.tokenLaunch.count(),
    prisma.tokenLaunch.count({ where: { isRug: true } }),
    prisma.smartWallet.count({ where: { trustScore: { gte: 50 } } }),
    prisma.alphaAlert.count({ where: { type: 'ALPHA_SIGNAL', createdAt: { gte: new Date(Date.now() - 86400000) } } }),
  ])
  return { tokens, rugCount, wallets, alerts }
}

export default async function DashboardPage() {
  const stats = await getStats()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Overview" />
      <div className="flex-1 p-6 overflow-auto">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <StatCard label="Tokens Indexed" value={stats.tokens.toLocaleString()} sub="all time" icon={TrendingUp} color="brand" />
          <StatCard label="Rugs Detected" value={stats.rugCount.toLocaleString()} sub="protected" icon={Shield} color="danger" />
          <StatCard label="Smart Wallets" value={stats.wallets} sub="active" icon={Wallet} color="info" />
          <StatCard label="Alpha Signals (24h)" value={stats.alerts} sub="BUY signals" icon={Zap} color="brand" trend="up" />
        </div>

        {/* Main grid */}
        <div className="grid grid-cols-3 gap-4">
          {/* Live feed takes 1 col */}
          <div className="col-span-1 h-[500px]">
            <LiveFeed />
          </div>
          {/* Jito chart takes 2 cols */}
          <div className="col-span-2">
            <JitoChart />
          </div>
        </div>

        {/* Quick start banner if no data */}
        {stats.tokens === 0 && (
          <div className="mt-6 card-glow p-6">
            <h3 className="font-display font-600 text-white mb-2">🚀 Engine not running</h3>
            <p className="text-sm text-slate-400 mb-4">
              No token data yet. Start the engine to begin indexing Solana launches.
            </p>
            <div className="bg-surface rounded-lg p-4 font-mono text-xs text-slate-300 space-y-1">
              <div><span className="text-brand">$</span> cp .env.example .env</div>
              <div><span className="text-brand">$</span> npm install</div>
              <div><span className="text-brand">$</span> npm run db:push</div>
              <div><span className="text-brand">$</span> npm run dev</div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
