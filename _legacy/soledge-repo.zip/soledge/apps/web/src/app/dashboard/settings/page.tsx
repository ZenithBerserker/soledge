'use client'
import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { TopBar } from '@/components/dashboard/TopBar'
import { Key, Copy, RefreshCw, Trash2, Check } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ApiKey {
  id: string
  name: string
  key: string
  calls: number
  lastUsed: string | null
  createdAt: string
}

export default function SettingsPage() {
  const { data: session } = useSession()
  const role = (session?.user as any)?.role ?? 'FREE'
  const [keys, setKeys] = useState<ApiKey[]>([])
  const [newName, setNewName] = useState('')
  const [creating, setCreating] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/keys').then(r => r.json()).then(r => setKeys(r.data ?? []))
  }, [])

  async function createKey() {
    if (!newName.trim()) return
    setCreating(true)
    const res = await fetch('/api/keys', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newName }),
    })
    const { data } = await res.json()
    if (data) { setKeys(prev => [data, ...prev]); setNewName('') }
    setCreating(false)
  }

  async function deleteKey(id: string) {
    await fetch(`/api/keys?id=${id}`, { method: 'DELETE' })
    setKeys(prev => prev.filter(k => k.id !== id))
  }

  function copyKey(key: string) {
    navigator.clipboard.writeText(key)
    setCopied(key)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Settings & API Keys" />
      <div className="p-6 max-w-2xl space-y-6">
        {/* Plan info */}
        <div className="card p-5">
          <h3 className="font-display font-600 text-white mb-1">Current Plan</h3>
          <div className={cn(
            'inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-mono border mt-2',
            role === 'FREE' ? 'text-slate-400 border-slate-700 bg-slate-800/40' :
            role === 'PRO' ? 'text-brand border-brand/30 bg-brand/5' :
            'text-warn border-warn/30 bg-warn/5'
          )}>
            {role}
            {role === 'FREE' && <span className="text-slate-600 text-xs">— upgrade for API access</span>}
          </div>
        </div>

        {/* API Keys */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <Key className="w-4 h-4 text-brand" />
            <h3 className="font-display font-600 text-white">API Keys</h3>
            <span className="text-xs text-slate-600 ml-1">(ELITE only)</span>
          </div>

          {role !== 'ELITE' && role !== 'ADMIN' ? (
            <div className="text-sm text-slate-500 font-mono py-4 text-center">
              Raw API access requires the Elite plan.{' '}
              <a href="/upgrade" className="text-brand hover:underline">Upgrade →</a>
            </div>
          ) : (
            <>
              {/* Create */}
              <div className="flex gap-2 mb-5">
                <input
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && createKey()}
                  placeholder="Key name (e.g. my-bot)"
                  className="flex-1 bg-surface border border-surface-border rounded-lg px-3 py-2 text-sm text-white placeholder-slate-600 font-mono focus:outline-none focus:border-brand/40"
                />
                <button
                  onClick={createKey}
                  disabled={creating || !newName.trim()}
                  className="px-4 py-2 bg-brand text-black text-sm font-semibold rounded-lg hover:bg-brand-dim transition-all disabled:opacity-40"
                >
                  {creating ? '...' : 'Create'}
                </button>
              </div>

              {/* Key list */}
              {keys.length === 0 ? (
                <p className="text-sm text-slate-600 font-mono text-center py-4">No API keys yet.</p>
              ) : (
                <div className="space-y-2">
                  {keys.map(k => (
                    <div key={k.id} className="flex items-center gap-3 p-3 bg-surface rounded-lg border border-surface-border">
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-white font-mono">{k.name}</div>
                        <div className="text-xs text-slate-600 font-mono truncate mt-0.5">{k.key}</div>
                        <div className="text-xs text-slate-700 mt-1">{k.calls.toLocaleString()} calls · {k.lastUsed ? `last used ${new Date(k.lastUsed).toLocaleDateString()}` : 'never used'}</div>
                      </div>
                      <button onClick={() => copyKey(k.key)} className="p-1.5 rounded hover:bg-surface-hover transition-colors">
                        {copied === k.key ? <Check className="w-3.5 h-3.5 text-brand" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                      </button>
                      <button onClick={() => deleteKey(k.id)} className="p-1.5 rounded hover:bg-danger/10 transition-colors">
                        <Trash2 className="w-3.5 h-3.5 text-slate-500 hover:text-danger" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
