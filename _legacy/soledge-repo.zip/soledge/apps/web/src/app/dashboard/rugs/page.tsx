import { TopBar } from '@/components/dashboard/TopBar'
import { prisma } from '@soledge/db'
import { Shield, AlertTriangle } from 'lucide-react'
import { truncate } from '@/lib/utils'

export const dynamic = 'force-dynamic'

async function getRugs() {
  return prisma.alphaAlert.findMany({
    where: { type: 'RUG_DETECTED' },
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: { token: { select: { mintAddress: true, symbol: true, rugType: true, ruggedAt: true } } },
  })
}

export default async function RugsPage() {
  const rugs = await getRugs()

  return (
    <div className="flex flex-col h-full">
      <TopBar title="Rug Alerts" />
      <div className="p-6">
        <div className="flex items-center gap-3 mb-6 p-4 rounded-xl border border-danger/20 bg-danger/5">
          <AlertTriangle className="w-5 h-5 text-danger shrink-0" />
          <p className="text-sm text-danger/80">
            {rugs.length} rugs detected. These alerts are sent to the <strong>free</strong> Telegram/Discord channel as a marketing funnel.
          </p>
        </div>

        {rugs.length === 0 ? (
          <div className="card p-12 text-center">
            <Shield className="w-10 h-10 text-brand mx-auto mb-3" />
            <p className="text-slate-400 font-mono text-sm">No rugs detected yet.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {rugs.map(r => (
              <div key={r.id} className="card p-4 border-danger/10 hover:border-danger/25 transition-all">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-danger/10 border border-danger/20 flex items-center justify-center">
                      <Shield className="w-4 h-4 text-danger" />
                    </div>
                    <div>
                      <div className="font-mono text-sm text-white">{r.title}</div>
                      <div className="text-xs text-slate-500 mt-0.5">{r.token?.mintAddress ? truncate(r.token.mintAddress, 8, 8) : '—'}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    {r.token?.rugType && (
                      <span className="text-xs font-mono text-danger/70 border border-danger/20 px-2 py-0.5 rounded">
                        {r.token.rugType.replace(/_/g,' ')}
                      </span>
                    )}
                    <div className="text-xs text-slate-600 mt-1">{new Date(r.createdAt).toLocaleString()}</div>
                  </div>
                </div>
                <p className="text-xs text-slate-500 mt-2 ml-11">{r.body}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
