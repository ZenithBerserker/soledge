import Link from 'next/link'
import { ArrowRight, Shield, Zap, Brain, TrendingUp, Activity, Lock } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-surface overflow-hidden">
      {/* Background grid + radial */}
      <div className="fixed inset-0 bg-grid-pattern bg-grid opacity-100 pointer-events-none" />
      <div className="fixed inset-0 bg-radial-brand pointer-events-none" />

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-4 border-b border-surface-border/50 backdrop-blur-sm">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand/20 border border-brand/40 flex items-center justify-center">
            <Zap className="w-4 h-4 text-brand" />
          </div>
          <span className="font-display font-700 text-lg tracking-tight text-white">SolEdge</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="text-sm text-slate-400 hover:text-white transition-colors">Dashboard</Link>
          <Link href="/upgrade" className="text-sm text-slate-400 hover:text-white transition-colors">Pricing</Link>
          <Link href="/docs" className="text-sm text-slate-400 hover:text-white transition-colors">Docs</Link>
          <Link href="/auth/signin" className="px-4 py-1.5 text-sm bg-brand text-black font-semibold rounded-lg hover:bg-brand-dim transition-colors">
            Get Access
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative z-10 max-w-5xl mx-auto px-6 pt-24 pb-20 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-brand/30 bg-brand/5 text-brand text-xs font-mono mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-brand blink" />
          LIVE — Real-time Solana intelligence
        </div>

        <h1 className="font-display text-5xl md:text-7xl font-700 text-white leading-[1.05] tracking-tight mb-6">
          MEV-grade alpha<br />
          <span className="text-brand text-glow">before the crowd</span>
        </h1>

        <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          Real-time token safety scoring, smart money wallet tracking, Jito bundle analytics,
          and coordinated exit detection. Everything retail can&apos;t build.
        </p>

        <div className="flex items-center justify-center gap-4">
          <Link href="/dashboard" className="flex items-center gap-2 px-6 py-3 bg-brand text-black font-semibold rounded-xl hover:bg-brand-dim transition-all hover:scale-105 glow-brand">
            Open Dashboard <ArrowRight className="w-4 h-4" />
          </Link>
          <Link href="/upgrade" className="px-6 py-3 border border-surface-border text-white rounded-xl hover:border-brand/30 hover:bg-brand/5 transition-all">
            View Pricing
          </Link>
        </div>

        {/* Live stats bar */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Tokens Scanned', value: '47,293', sub: 'since launch' },
            { label: 'Rugs Detected', value: '8,441', sub: 'protected users' },
            { label: 'Smart Wallets', value: '127', sub: 'tracked live' },
            { label: 'Avg Signal Score', value: '73/100', sub: 'on BUY alerts' },
          ].map((stat) => (
            <div key={stat.label} className="card p-4 text-left">
              <div className="text-2xl font-mono font-bold text-white mb-1">{stat.value}</div>
              <div className="text-xs text-slate-400">{stat.label}</div>
              <div className="text-xs text-slate-600">{stat.sub}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 pb-24">
        <h2 className="font-display text-3xl font-700 text-white text-center mb-12">
          Every edge. One platform.
        </h2>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Shield,
              color: 'text-brand',
              bg: 'bg-brand/10 border-brand/20',
              title: 'Token Safety Engine',
              desc: 'Mint authority, freeze authority, LP lock status, supply concentration, and bundle detection — all checked in < 500ms.',
            },
            {
              icon: Brain,
              color: 'text-info',
              bg: 'bg-info/10 border-info/20',
              title: 'Smart Money Tracking',
              desc: '127+ tracked wallets with reputation scoring. Get alerted when insiders and whales accumulate.',
            },
            {
              icon: Activity,
              color: 'text-warn',
              bg: 'bg-warn/10 border-warn/20',
              title: 'Coordinated Exit Detection',
              desc: '3+ smart wallets selling in the same slot window triggers an immediate rug alert to all subscribers.',
            },
            {
              icon: TrendingUp,
              color: 'text-brand',
              bg: 'bg-brand/10 border-brand/20',
              title: 'Sentiment Fusion',
              desc: 'LunarCrush + Telegram + Discord signal fusion. Social velocity correlated against on-chain liquidity depth.',
            },
            {
              icon: Zap,
              color: 'text-warn',
              bg: 'bg-warn/10 border-warn/20',
              title: 'Jito Bundle Analytics',
              desc: 'Real-time tip floor monitoring with EMA smoothing. Optimal tip calculation for 75th/95th/99th percentile landing.',
            },
            {
              icon: Lock,
              color: 'text-info',
              bg: 'bg-info/10 border-info/20',
              title: 'Raw API Access',
              desc: 'Elite subscribers get full JSON access to our scoring engine. Build your own bot on our intelligence layer.',
            },
          ].map((f) => (
            <div key={f.title} className="card p-6 hover:border-surface-border/80 transition-all hover:-translate-y-0.5">
              <div className={`w-10 h-10 rounded-lg border ${f.bg} flex items-center justify-center mb-4`}>
                <f.icon className={`w-5 h-5 ${f.color}`} />
              </div>
              <h3 className="font-display font-600 text-white mb-2">{f.title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 max-w-4xl mx-auto px-6 pb-24 text-center">
        <div className="card-glow p-12">
          <h2 className="font-display text-3xl font-700 text-white mb-4">Start trading smarter today</h2>
          <p className="text-slate-400 mb-8">Free tier includes rug alerts. Pro and Elite unlock the full alpha stack.</p>
          <div className="flex items-center justify-center gap-4">
            <Link href="/auth/signin" className="px-8 py-3 bg-brand text-black font-semibold rounded-xl hover:bg-brand-dim transition-all glow-brand">
              Create Free Account
            </Link>
            <Link href="/upgrade" className="px-8 py-3 border border-surface-border text-white rounded-xl hover:border-brand/30 transition-all">
              View Plans — from $49/mo
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-surface-border px-6 py-8">
        <div className="max-w-6xl mx-auto flex items-center justify-between text-sm text-slate-600">
          <span className="font-display font-600 text-slate-500">SolEdge</span>
          <span>Not financial advice. Trade responsibly.</span>
          <div className="flex gap-4">
            <Link href="/docs" className="hover:text-slate-400 transition-colors">Docs</Link>
            <Link href="/upgrade" className="hover:text-slate-400 transition-colors">Pricing</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
