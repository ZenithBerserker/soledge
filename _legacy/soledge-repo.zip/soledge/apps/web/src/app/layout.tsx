import type { Metadata } from 'next'
import './globals.css'
import { Providers } from './providers'

export const metadata: Metadata = {
  title: 'SolEdge — Solana MEV Intelligence',
  description: 'Real-time MEV-grade signal intelligence for Solana tokens. Smart money tracking, rug detection, Jito bundle analytics.',
  keywords: 'Solana, MEV, trading bot, smart money, rug detection, DeFi',
  openGraph: {
    title: 'SolEdge — Solana MEV Intelligence',
    description: 'Real-time alpha signals, smart money tracking, and rug detection for Solana.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
