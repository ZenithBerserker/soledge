import Link from 'next/link'
import { Zap } from 'lucide-react'

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-surface">
      <div className="fixed inset-0 bg-grid-pattern bg-grid opacity-100 pointer-events-none" />
      <nav className="relative z-10 flex items-center gap-4 px-6 py-4 border-b border-surface-border">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-brand/20 border border-brand/40 flex items-center justify-center">
            <Zap className="w-3.5 h-3.5 text-brand" />
          </div>
          <span className="font-display font-700 text-white text-sm">SolEdge</span>
        </Link>
        <span className="text-slate-600">/</span>
        <span className="text-slate-400 text-sm">Docs</span>
      </nav>

      <div className="relative z-10 max-w-3xl mx-auto px-6 py-14 prose prose-invert prose-sm">
        <h1 className="font-display text-3xl font-700 text-white">SolEdge API & Docs</h1>
        <p className="text-slate-400">Elite tier API access for programmatic signal consumption.</p>

        <h2 className="font-display text-xl font-600 text-white mt-10 mb-4">Authentication</h2>
        <p className="text-slate-400 mb-3">All API routes require your API key as a Bearer token:</p>
        <div className="card p-4 font-mono text-xs text-slate-300">
          Authorization: Bearer sk_elite_xxxxxxxxxxxx
        </div>

        <h2 className="font-display text-xl font-600 text-white mt-10 mb-4">Endpoints</h2>

        {[
          {
            method: 'GET', path: '/api/signals', tier: 'FREE+',
            desc: 'List alpha signals with optional filter=BUY|WATCH|RUG.',
            response: '{ success, data: { alerts[], total, page, hasMore } }',
          },
          {
            method: 'GET', path: '/api/tokens?mint=<address>', tier: 'FREE+',
            desc: 'Fetch indexed token data with smart money activity.',
            response: '{ success, data: TokenLaunch }',
          },
          {
            method: 'GET', path: '/api/wallets', tier: 'PRO+',
            desc: 'List smart money wallets. Returns top 3/12/unlimited based on tier.',
            response: '{ success, data: SmartWallet[] }',
          },
          {
            method: 'GET', path: '/api/jito-metrics', tier: 'PRO+',
            desc: 'Live Jito tip floor and historical snapshots.',
            response: '{ success, data: { live, history[] } }',
          },
        ].map(e => (
          <div key={e.path} className="card p-5 mb-3">
            <div className="flex items-center gap-3 mb-2">
              <span className="font-mono text-xs text-brand border border-brand/30 bg-brand/5 px-2 py-0.5 rounded">{e.method}</span>
              <code className="font-mono text-sm text-white">{e.path}</code>
              <span className="ml-auto text-xs text-slate-500 font-mono">{e.tier}</span>
            </div>
            <p className="text-sm text-slate-400 mb-2">{e.desc}</p>
            <div className="font-mono text-xs text-slate-600">{e.response}</div>
          </div>
        ))}

        <h2 className="font-display text-xl font-600 text-white mt-10 mb-4">WebSocket Events</h2>
        <p className="text-slate-400 mb-3">Connect to <code className="text-brand">ws://your-engine-host:3001?token=JWT</code></p>

        <div className="card p-4 font-mono text-xs space-y-2">
          {[
            { type: 'TOKEN_LAUNCH', tier: 'FREE', desc: 'New pool detected + scored' },
            { type: 'RUG_ALERT', tier: 'FREE', desc: 'Rug/honeypot detected' },
            { type: 'SMART_MONEY', tier: 'PRO+', desc: 'Tracked wallet buy/sell' },
            { type: 'SENTIMENT_SURGE', tier: 'PRO+', desc: 'Social velocity spike' },
            { type: 'JITO_METRICS', tier: 'FREE', desc: 'Tip floor snapshot' },
            { type: 'SLOT_UPDATE', tier: 'FREE', desc: 'Current slot + TPS' },
          ].map(e => (
            <div key={e.type} className="flex items-center gap-3">
              <span className="text-brand w-36">{e.type}</span>
              <span className="text-slate-600 w-14">{e.tier}</span>
              <span className="text-slate-500">{e.desc}</span>
            </div>
          ))}
        </div>

        <h2 className="font-display text-xl font-600 text-white mt-10 mb-4">Architecture</h2>
        <p className="text-slate-400 mb-3">SolEdge runs as a Turborepo monorepo with three apps:</p>
        <div className="card p-4 font-mono text-xs space-y-1.5 text-slate-400">
          <div><span className="text-brand">apps/web</span> — Next.js 14 dashboard + API routes (deploy to Vercel)</div>
          <div><span className="text-brand">apps/engine</span> — Node.js signal engine (deploy to bare-metal or Railway)</div>
          <div><span className="text-brand">apps/bot</span> — Discord + Telegram bots (deploy alongside engine)</div>
          <div><span className="text-brand">packages/db</span> — Prisma schema + client (PostgreSQL)</div>
          <div><span className="text-brand">packages/types</span> — Shared TypeScript types</div>
        </div>

        <div className="mt-10 card-glow p-6 text-center">
          <p className="text-slate-400 text-sm mb-4">Need raw API access? Upgrade to Elite.</p>
          <Link href="/upgrade" className="px-6 py-2.5 bg-brand text-black font-semibold rounded-xl text-sm hover:bg-brand-dim transition-all">
            View Plans
          </Link>
        </div>
      </div>
    </div>
  )
}
