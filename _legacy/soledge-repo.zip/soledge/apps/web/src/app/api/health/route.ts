import { NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  let db = false
  let oppCount = 0
  let liveCount = 0

  try {
    oppCount = await prisma.arbOpportunity.count()
    liveCount = await prisma.arbOpportunity.count({ where: { status: 'LIVE' } })
    db = true
  } catch {}

  return NextResponse.json({
    ok: true,
    db,
    opportunities: { total: oppCount, live: liveCount },
    ts: new Date().toISOString(),
  })
}
