import { NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  let db = false
  let tableReady = false
  let oppCount = 0
  let liveCount = 0
  let error: string | undefined

  try {
    // Basic connectivity
    await prisma.$queryRaw`SELECT 1`
    db = true

    // Check if ArbOpportunity table exists
    try {
      oppCount = await prisma.arbOpportunity.count()
      liveCount = await prisma.arbOpportunity.count({ where: { status: 'LIVE' } })
      tableReady = true
    } catch (e: any) {
      // Table doesn't exist yet — schema not pushed
      error = 'ArbOpportunity table missing — run: npx prisma db push'
    }
  } catch (e: any) {
    error = e.message?.slice(0, 120)
  }

  const secretConfigured = !!(
    process.env.ENGINE_INGEST_SECRET || process.env.ENGINE_BOT_TOKEN
  )

  return NextResponse.json({
    ok: db && tableReady,
    db,
    tableReady,
    secretConfigured,
    opportunities: { total: oppCount, live: liveCount },
    env: {
      hasDatabase:  !!process.env.DATABASE_URL,
      hasSecret:    secretConfigured,
    },
    error,
    ts: new Date().toISOString(),
  })
}
