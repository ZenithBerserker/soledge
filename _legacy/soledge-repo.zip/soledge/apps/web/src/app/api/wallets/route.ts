import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@soledge/db'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  const tier = (session?.user as any)?.role ?? 'FREE'

  const limit = tier === 'FREE' ? 3 : tier === 'PRO' ? 12 : 100

  const wallets = await prisma.smartWallet.findMany({
    where: { trustScore: { gte: tier === 'FREE' ? 70 : 50 } },
    orderBy: [{ trustScore: 'desc' }, { totalPnlUsd: 'desc' }],
    take: limit,
    include: {
      _count: { select: { activities: true } },
    },
  })

  return NextResponse.json({ success: true, data: wallets })
}
