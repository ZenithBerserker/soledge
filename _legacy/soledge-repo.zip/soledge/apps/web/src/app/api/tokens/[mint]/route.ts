// apps/web/src/app/api/tokens/[mint]/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export async function GET(
  _req: NextRequest,
  { params }: { params: { mint: string } }
) {
  const { mint } = params

  // First try DB
  const cached = await prisma.tokenLaunch.findUnique({
    where: { mintAddress: mint },
    include: {
      smartMoneyActivities: {
        orderBy: { createdAt: 'desc' },
        take: 10,
        include: { wallet: { select: { label: true, trustScore: true, category: true } } }
      },
      alphaAlerts: {
        orderBy: { createdAt: 'desc' },
        take: 5,
      }
    }
  })

  if (cached) {
    return NextResponse.json({ success: true, data: cached, source: 'cache' })
  }

  // Not in DB — need engine to scan
  return NextResponse.json({
    success: false,
    error: 'Token not yet indexed. Start the engine and it will be scanned automatically.',
    hint: 'POST /api/signals with engine token to ingest manually'
  }, { status: 404 })
}
