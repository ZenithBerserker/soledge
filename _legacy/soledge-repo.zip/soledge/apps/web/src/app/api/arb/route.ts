// apps/web/src/app/api/arb/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status')
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '20'), 100)

  const where: any = {}
  if (status) where.status = status

  const opportunities = await prisma.arbOpportunity.findMany({
    where,
    orderBy: { detectedAt: 'desc' },
    take: limit,
  })

  return NextResponse.json({ success: true, data: opportunities })
}

export async function POST(req: NextRequest) {
  const auth = req.headers.get('authorization')
  if (auth !== `Bearer ${process.env.ENGINE_BOT_TOKEN}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()

  const opp = await prisma.arbOpportunity.create({
    data: {
      poolAddress:       body.poolAddress,
      tokenPair:         body.tokenPair,
      entryAmountSol:    body.estimatedEntryAmount,
      projectedReturnX:  body.projectedReturnX,
      projectedReturnUsd: body.projectedReturnUsd,
      routeSteps:        body.routeSteps,
      jitoTipSol:        body.jitoTipRecommended,
      confidenceLevel:   body.confidenceLevel ?? 'MEDIUM',
      poolLiquidityUsd:  body.poolLiquidityUsd ?? 0,
      status:            'LIVE',
      detectedAt:        new Date(body.detectedAt ?? Date.now()),
      expiresAt:         new Date(body.expiresAt ?? Date.now() + 30_000),
    }
  })

  // Create alert
  await prisma.alphaAlert.create({
    data: {
      type:  'ARB_DETECTED',
      tier:  'PRO',
      title: `🔮 ARB OPPORTUNITY: ${body.tokenPair?.join(' → ')}`,
      body:  `${body.projectedReturnX}x projected return ($${body.projectedReturnUsd?.toFixed(0)}) via Meteora`,
      metadata: body,
    }
  }).catch(() => {})

  return NextResponse.json({ success: true, data: opp })
}
