// apps/web/src/app/api/alerts/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const tier = searchParams.get('tier') ?? 'FREE'
  const type = searchParams.get('type')
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '20'), 100)

  const where: any = {}
  // Free tier only sees FREE alerts
  if (tier === 'FREE') where.tier = 'FREE'
  if (type) where.type = type

  const alerts = await prisma.alphaAlert.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: {
      token: {
        select: { symbol: true, mintAddress: true, recommendation: true }
      }
    }
  })

  return NextResponse.json({ success: true, data: alerts })
}

// Ingest alert from engine
export async function POST(req: NextRequest) {
  const auth = req.headers.get('authorization')
  if (auth !== `Bearer ${process.env.ENGINE_BOT_TOKEN}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()

  let tokenId: string | undefined
  if (body.mintAddress) {
    const token = await prisma.tokenLaunch.findUnique({
      where: { mintAddress: body.mintAddress },
      select: { id: true }
    })
    tokenId = token?.id
  }

  const alert = await prisma.alphaAlert.create({
    data: {
      tokenId,
      type:     body.type,
      tier:     body.tier ?? 'FREE',
      title:    body.title,
      body:     body.body,
      metadata: body.metadata ?? {},
    }
  })

  return NextResponse.json({ success: true, data: alert })
}
