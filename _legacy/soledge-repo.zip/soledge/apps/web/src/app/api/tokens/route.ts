import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const mint = searchParams.get('mint')

  if (mint) {
    const token = await prisma.tokenLaunch.findUnique({
      where: { mintAddress: mint },
      include: {
        smartMoneyBuys: {
          take: 10,
          orderBy: { createdAt: 'desc' },
          include: { wallet: true },
        },
        sentimentLogs: { take: 5, orderBy: { createdAt: 'desc' } },
        alerts: { take: 5, orderBy: { createdAt: 'desc' } },
      },
    })
    if (!token) return NextResponse.json({ success: false, error: 'Not found' }, { status: 404 })
    return NextResponse.json({ success: true, data: token })
  }

  const tokens = await prisma.tokenLaunch.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
    where: { safetyScore: { gte: 50 } },
  })

  return NextResponse.json({ success: true, data: tokens })
}
