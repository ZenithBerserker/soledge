import { NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export async function GET() {
  // Fetch latest 30 snapshots for chart
  const snapshots = await prisma.jitoMetricSnapshot.findMany({
    orderBy: { createdAt: 'desc' },
    take: 30,
  })

  // Also fetch from live Jito API
  let live = null
  try {
    const resp = await fetch('https://bundles.jito.wtf/api/v1/bundles/tip_floor')
    const [data] = await resp.json()
    live = {
      p25: Math.round(data.landed_tips_25th_percentile * 1e9),
      p50: Math.round(data.landed_tips_50th_percentile * 1e9),
      p75: Math.round(data.landed_tips_75th_percentile * 1e9),
      p95: Math.round(data.landed_tips_95th_percentile * 1e9),
      p99: Math.round(data.landed_tips_99th_percentile * 1e9),
    }
  } catch {}

  return NextResponse.json({ success: true, data: { live, history: snapshots.reverse() } })
}
