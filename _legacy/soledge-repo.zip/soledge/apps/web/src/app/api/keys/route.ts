import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@soledge/db'
import { randomBytes } from 'crypto'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = (session.user as any).id
  const keys = await prisma.apiKey.findMany({ where: { userId, active: true }, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ success: true, data: keys })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const userId = (session.user as any).id
  const role = (session.user as any).role
  if (role !== 'ELITE' && role !== 'ADMIN') {
    return NextResponse.json({ error: 'Elite plan required' }, { status: 403 })
  }
  const { name } = await req.json()
  const key = `sk_elite_${randomBytes(24).toString('hex')}`
  const apiKey = await prisma.apiKey.create({ data: { userId, key, name } })
  return NextResponse.json({ success: true, data: apiKey })
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')
  if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 })
  const userId = (session.user as any).id
  await prisma.apiKey.updateMany({ where: { id, userId }, data: { active: false } })
  return NextResponse.json({ success: true })
}
