// apps/web/src/app/api/migrate/route.ts
// Creates the ArbOpportunity table if it doesn't exist.
// Protected by ENGINE_INGEST_SECRET — safe to expose publicly.
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

function isAuthorized(req: NextRequest): boolean {
  const secret = process.env.ENGINE_INGEST_SECRET ?? process.env.ENGINE_BOT_TOKEN ?? ''
  if (!secret) return false
  const h = req.headers.get('x-engine-secret') ?? ''
  const b = req.headers.get('authorization')?.replace('Bearer ', '') ?? ''
  return h === secret || b === secret
}

export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: 'Unauthorized — provide x-engine-secret header' }, { status: 401 })
  }

  try {
    // Create table if not exists using raw SQL (works even if Prisma migrate hasn't run)
    await prisma.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "ArbOpportunity" (
        "id"                TEXT NOT NULL PRIMARY KEY,
        "pairs"             TEXT[] NOT NULL DEFAULT '{}',
        "poolAddress"       TEXT,
        "tokenPair"         TEXT NOT NULL DEFAULT '',
        "entryAmountLabel"  TEXT NOT NULL DEFAULT '',
        "entryAmountSol"    DOUBLE PRECISION NOT NULL DEFAULT 0,
        "projectedReturnX"  DOUBLE PRECISION NOT NULL,
        "projectedReturnUsd" DOUBLE PRECISION NOT NULL,
        "projectedProfitUsd" DOUBLE PRECISION NOT NULL DEFAULT 0,
        "routeSteps"        TEXT[] NOT NULL DEFAULT '{}',
        "jitoTipSol"        DOUBLE PRECISION NOT NULL DEFAULT 0,
        "confidenceLevel"   TEXT NOT NULL DEFAULT 'MEDIUM',
        "poolLiquidityUsd"  DOUBLE PRECISION NOT NULL DEFAULT 0,
        "slippagePct"       DOUBLE PRECISION NOT NULL DEFAULT 0,
        "status"            TEXT NOT NULL DEFAULT 'LIVE',
        "detectedAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "expiresAt"         TIMESTAMP(3),
        "executedAt"        TIMESTAMP(3),
        "createdAt"         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
    `)

    await prisma.$executeRawUnsafe(`
      CREATE INDEX IF NOT EXISTS "ArbOpportunity_detectedAt_idx" ON "ArbOpportunity"("detectedAt");
    `)
    await prisma.$executeRawUnsafe(`
      CREATE INDEX IF NOT EXISTS "ArbOpportunity_status_idx" ON "ArbOpportunity"("status");
    `)

    // Also add ARB_DETECTED to AlertType enum if it's missing
    await prisma.$executeRawUnsafe(`
      DO $$ BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_enum
          WHERE enumlabel = 'ARB_DETECTED'
          AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'AlertType')
        ) THEN
          ALTER TYPE "AlertType" ADD VALUE IF NOT EXISTS 'ARB_DETECTED';
        END IF;
      EXCEPTION WHEN others THEN NULL;
      END $$;
    `).catch(() => {}) // ignore if enum doesn't exist yet

    return NextResponse.json({ success: true, message: 'ArbOpportunity table ready' })
  } catch (e: any) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 })
  }
}
