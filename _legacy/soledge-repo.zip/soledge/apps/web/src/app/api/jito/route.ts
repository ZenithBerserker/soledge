// apps/web/src/app/api/jito/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

// Get latest Jito tip data (also fetches live from Jito)
export async function GET() {
  try {
    // Try to fetch live from Jito
    const resp = await fetch('https://bundles.jito.wtf/api/v1/bundles/tip_floor', {
      next: { revalidate: 5 }
    })
    const [data] = await resp.json()

    const floor = {
      p25: Math.round(data.landed_tips_25th_percentile * 1e9),
      p50: Math.round(data.landed_tips_50th_percentile * 1e9),
      p75: Math.round(data.landed_tips_75th_percentile * 1e9),
      p95: Math.round(data.landed_tips_95th_percentile * 1e9),
      p99: Math.round(data.landed_tips_99th_percentile * 1e9),
    }

    // Persist snapshot
    await prisma.jitoTipSnapshot.create({
      data: { ...floor, slot: BigInt(data.slot ?? 0) }
    }).catch(() => {})

    return NextResponse.json({ success: true, data: floor })
  } catch {
    // Fall back to DB
    const latest = await prisma.jitoTipSnapshot.findFirst({ orderBy: { createdAt: 'desc' } })
    if (latest) {
      return NextResponse.json({ success: true, data: latest, source: 'cache' })
    }
    return NextResponse.json({ success: false, error: 'No Jito data available' }, { status: 503 })
  }
}

// Ingest Jito metrics from engine
export async function POST(req: NextRequest) {
  const auth = req.headers.get('authorization')
  if (auth !== `Bearer ${process.env.ENGINE_BOT_TOKEN}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()

  const snapshot = await prisma.jitoTipSnapshot.create({
    data: {
      p25: body.p25,
      p50: body.p50,
      p75: body.p75,
      p95: body.p95,
      p99: body.p99,
      slot: BigInt(body.slot ?? 0),
    }
  })

  return NextResponse.json({ success: true, data: snapshot })
}
