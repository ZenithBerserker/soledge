// apps/web/src/app/api/opportunities/route.ts
// Ingest endpoint for the Meteora DLMM worker + read endpoint for the dashboard
// Auth: x-engine-secret header OR Authorization: Bearer <ENGINE_INGEST_SECRET>

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@soledge/db'

export const dynamic = 'force-dynamic'

function isAuthorized(req: NextRequest): boolean {
  const secret = process.env.ENGINE_INGEST_SECRET ?? process.env.ENGINE_BOT_TOKEN ?? ''
  if (!secret) return false
  const header = req.headers.get('x-engine-secret') ?? ''
  const bearer = req.headers.get('authorization')?.replace('Bearer ', '') ?? ''
  return header === secret || bearer === secret
}

// ─── GET — list opportunities for dashboard ───────────────────────────────────

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') ?? 'LIVE'
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '50'), 200)

  // Auto-expire stale opportunities
  await prisma.arbOpportunity.updateMany({
    where: {
      status: 'LIVE',
      expiresAt: { lt: new Date() },
    },
    data: { status: 'EXPIRED' },
  }).catch(() => {})

  const opps = await prisma.arbOpportunity.findMany({
    where: status === 'ALL' ? {} : { status },
    orderBy: { detectedAt: 'desc' },
    take: limit,
  })

  return NextResponse.json({ success: true, data: opps })
}

// ─── POST — worker pushes a detected opportunity ──────────────────────────────

export async function POST(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  // Validate required fields
  const required = ['pairs', 'projectedReturnX', 'projectedReturnUsd']
  for (const f of required) {
    if (body[f] === undefined) {
      return NextResponse.json({ error: `Missing field: ${f}` }, { status: 400 })
    }
  }

  // Hard gate: only store opportunities worth acting on
  if (body.projectedReturnX < 2) {
    return NextResponse.json({ error: 'projectedReturnX too low (min 2x)' }, { status: 422 })
  }
  if ((body.slippagePct ?? 0) > 30) {
    return NextResponse.json({ error: 'Slippage too high (max 30%)' }, { status: 422 })
  }

  const now = new Date()
  const ttlMs = body.ttlSeconds ? body.ttlSeconds * 1000 : 30_000

  const opp = await prisma.arbOpportunity.create({
    data: {
      pairs:               Array.isArray(body.pairs) ? body.pairs : [body.pairs],
      poolAddress:         body.poolAddress ?? null,
      tokenPair:           body.pairs?.join(' → ') ?? body.tokenPair ?? 'UNKNOWN',
      entryAmountLabel:    body.entryAmountLabel ?? `${body.entryAmountSol ?? 0} SOL`,
      entryAmountSol:      body.entryAmountSol ?? 0,
      projectedReturnX:    body.projectedReturnX,
      projectedReturnUsd:  body.projectedReturnUsd,
      projectedProfitUsd:  body.projectedProfitUsd ?? (body.projectedReturnUsd - (body.entryAmountSol ?? 0) * 150),
      routeSteps:          body.routeSteps ?? body.pairs ?? [],
      jitoTipSol:          body.jitoTipRecommended ?? body.jitoTipSol ?? 0,
      confidenceLevel:     body.confidenceLevel ?? 'MEDIUM',
      poolLiquidityUsd:    body.poolLiquidityUsd ?? 0,
      slippagePct:         body.slippagePct ?? 0,
      status:              'LIVE',
      detectedAt:          body.detectedAt ? new Date(body.detectedAt) : now,
      expiresAt:           new Date(now.getTime() + ttlMs),
    },
  })

  // Create an alpha alert so it shows up in the signals feed too
  await prisma.alphaAlert.create({
    data: {
      type:     'ARB_DETECTED',
      tier:     'PRO',
      title:    `🔮 ARB: ${opp.tokenPair}`,
      body:     `${opp.projectedReturnX.toFixed(1)}x projected · $${opp.projectedReturnUsd.toFixed(0)} · Tip: ${opp.jitoTipSol} SOL · ${opp.confidenceLevel}`,
      metadata: body,
    },
  }).catch(() => {})

  return NextResponse.json({ success: true, id: opp.id }, { status: 201 })
}
