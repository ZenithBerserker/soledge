import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@soledge/db'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  const { searchParams } = new URL(req.url)
  const tier = (session?.user as any)?.role ?? 'FREE'
  const page = Number(searchParams.get('page') ?? 1)
  const limit = Number(searchParams.get('limit') ?? 20)
  const filter = searchParams.get('filter') // BUY | WATCH | RUG | SKIP

  const where: any = {}
  if (filter) where.type = filter === 'RUG' ? 'RUG_DETECTED' : 'ALPHA_SIGNAL'
  if (tier === 'FREE') where.tier = 'FREE'

  const [alerts, total] = await Promise.all([
    prisma.alphaAlert.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: (page - 1) * limit,
      include: { token: { select: { mintAddress: true, symbol: true, safetyScore: true, isRug: true, isHoneypot: true } } },
    }),
    prisma.alphaAlert.count({ where }),
  ])

  return NextResponse.json({
    success: true,
    data: { alerts, total, page, pageSize: limit, hasMore: page * limit < total },
  })
}
