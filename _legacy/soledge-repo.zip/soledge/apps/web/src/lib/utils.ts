import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatUsd(n: number): string {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`
  if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}K`
  return `$${n.toFixed(0)}`
}

export function formatSol(n: number): string {
  return `${n.toFixed(3)} SOL`
}

export function formatPct(n: number): string {
  return `${n > 0 ? '+' : ''}${n.toFixed(1)}%`
}

export function truncate(str: string, start = 4, end = 4): string {
  if (str.length <= start + end + 3) return str
  return `${str.slice(0, start)}...${str.slice(-end)}`
}

export function scoreColor(score: number): string {
  if (score >= 75) return 'text-brand'
  if (score >= 50) return 'text-warn'
  return 'text-danger'
}

export function recommendationColor(rec: string): string {
  switch (rec) {
    case 'BUY': return 'text-brand bg-brand/10 border-brand/30'
    case 'WATCH': return 'text-warn bg-warn/10 border-warn/30'
    case 'SKIP': return 'text-slate-400 bg-slate-400/10 border-slate-400/30'
    case 'RUG': return 'text-danger bg-danger/10 border-danger/30'
    default: return ''
  }
}
