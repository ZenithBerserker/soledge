import Stripe from 'stripe'

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? '', {
  apiVersion: '2024-04-10',
})

export const PLANS = {
  PRO: {
    name: 'Pro',
    price: 49,
    priceId: process.env.STRIPE_PRO_PRICE_ID ?? '',
    features: ['100 alerts/day', '12 smart wallets', '10k API calls', 'Discord + Telegram alerts', 'Backtest access'],
  },
  ELITE: {
    name: 'Elite',
    price: 199,
    priceId: process.env.STRIPE_ELITE_PRICE_ID ?? '',
    features: ['Unlimited alerts', 'Unlimited wallets', 'Unlimited API calls', 'Raw API access', 'Priority Jito tips', 'Deployer database'],
  },
}
