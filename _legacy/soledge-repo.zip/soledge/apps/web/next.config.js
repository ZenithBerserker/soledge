/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@soledge/types', '@soledge/db'],
  experimental: {
    serverComponentsExternalPackages: ['@prisma/client', 'prisma'],
  },
  webpack: (config) => {
    config.externals.push('@node-rs/argon2', '@node-rs/bcrypt')
    return config
  },
}

module.exports = nextConfig
