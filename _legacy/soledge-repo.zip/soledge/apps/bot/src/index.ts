import 'dotenv/config'
import { startDiscordBot } from './discord'
import { connectToEngine } from './telegram'

async function main() {
  console.log('🤖 SolEdge Bot starting...')
  await startDiscordBot()
  connectToEngine()
  console.log('✅ Bots running')
}

main().catch(console.error)
