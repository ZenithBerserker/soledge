// apps/bot/src/telegram.ts
// Telegram bot — paid subscribers via Stars/crypto payments

import TelegramBot from 'node-telegram-bot-api'
import { TokenSignal } from '@soledge/types'
import { prisma } from '../../engine/src/services/db'
import WebSocket from 'ws'

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN ?? '', { polling: true })

// Channel IDs (use -100xxxxxxxxxx format for public channels)
const CHANNELS = {
  FREE:  process.env.TG_CH_FREE  ?? '',   // public — scam alerts
  PRO:   process.env.TG_CH_PRO   ?? '',   // paid subscribers
  ELITE: process.env.TG_CH_ELITE ?? '',   // elite tier
}

// ─── Commands ─────────────────────────────────────────────────────────────

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id
  await bot.sendMessage(chatId, [
    '⚡ *SOLEDGE — Solana Alpha Intelligence*',
    '',
    'Real-time MEV-grade signal intelligence for Solana tokens.',
    '',
    '🛡️ */safety <mint>* — Check token safety scores',
    '🐋 */wallets* — View active smart money',
    '📊 */signal <mint>* — Get full signal report',
    '💎 */subscribe* — Upgrade to PRO/ELITE',
    '🔑 */apikey* — Get your API key (ELITE)',
    '',
    'Join the free channel for rug alerts: @soledge\\_free',
  ].join('\n'), { parse_mode: 'Markdown' })
})

bot.onText(/\/safety (.+)/, async (msg, match) => {
  const chatId = msg.chat.id
  const mint   = match?.[1]?.trim()
  if (!mint) return bot.sendMessage(chatId, 'Usage: /safety <mint_address>')

  await bot.sendMessage(chatId, '🔍 Analyzing token...')

  const token = await prisma.tokenLaunch.findUnique({ where: { mintAddress: mint } })
  if (!token) {
    return bot.sendMessage(chatId, `❓ Token not indexed yet. Use /signal to trigger a fresh scan.`)
  }

  const lines = [
    `*$${token.symbol ?? mint.slice(0,8)} Safety Report*`,
    '',
    `${token.mintAuthNull   ? '✅' : '❌'} Mint Authority: ${token.mintAuthNull ? 'NULL (safe)' : 'ACTIVE ⚠️'}`,
    `${token.freezeAuthNull ? '✅' : '❌'} Freeze Authority: ${token.freezeAuthNull ? 'NULL (safe)' : 'ACTIVE ⚠️'}`,
    `${token.lpLocked       ? '✅' : '❌'} LP Locked: ${token.lpLocked ? `Yes (${token.lpLockPlatform})` : 'NO ⚠️'}`,
    `${(token.top10Pct ?? 100) < 30 ? '✅' : '⚠️'} Top 10 Concentration: ${(token.top10Pct ?? 0).toFixed(1)}%`,
    `${token.isBundled ? '⚠️ BUNDLED LAUNCH DETECTED' : '✅ No bundling detected'}`,
    '',
    `🏆 Safety Score: *${token.safetyScore}/100*`,
    `📊 Verdict: *${token.isRug ? '☠️ RUG' : token.isHoneypot ? '🍯 HONEYPOT' : token.safetyScore >= 70 ? '✅ CLEAN' : '⚠️ RISKY'}*`,
  ]

  await bot.sendMessage(chatId, lines.join('\n'), {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [[
        { text: '🔗 Dexscreener', url: `https://dexscreener.com/solana/${mint}` },
        { text: '🐦 Birdeye',     url: `https://birdeye.so/token/${mint}?chain=solana` },
      ]]
    }
  })
})

bot.onText(/\/wallets/, async (msg) => {
  const chatId = msg.chat.id
  const user = await prisma.user.findFirst({ where: { } })  // look up by TG id in production

  const wallets = await prisma.smartWallet.findMany({
    where: { trustScore: { gte: 70 } },
    orderBy: { totalPnlUsd: 'desc' },
    take: 10,
  })

  if (!wallets.length) return bot.sendMessage(chatId, 'No smart wallets indexed yet.')

  const lines = wallets.map((w, i) =>
    `${i + 1}. \`${w.address.slice(0,8)}...\` — ${w.label ?? w.category} | ${w.winRate.toFixed(0)}% win | +$${formatNum(w.totalPnlUsd)}`
  )

  await bot.sendMessage(chatId,
    `🐋 *Top Smart Money Wallets*\n\n${lines.join('\n')}`,
    { parse_mode: 'Markdown' }
  )
})

bot.onText(/\/subscribe/, async (msg) => {
  const chatId = msg.chat.id
  await bot.sendMessage(chatId, [
    '💎 *SOLEDGE Subscription Plans*',
    '',
    '🆓 *Free* — $0/mo',
    '• Public rug/scam alerts',
    '• 3 smart wallet trackers',
    '',
    '⚡ *Pro* — $49/mo',
    '• All alpha signals',
    '• 12 smart wallet trackers',
    '• Discord + Telegram alerts',
    '• Backtest engine access',
    '',
    '🔱 *Elite* — $199/mo',
    '• Unlimited everything',
    '• Raw API access',
    '• Priority Jito bundle tips',
    '• Deployer reputation database',
  ].join('\n'), {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [
        [
          { text: '⚡ Get Pro — $49/mo',   url: `${process.env.NEXT_PUBLIC_APP_URL}/upgrade?plan=pro&ref=tg` },
          { text: '🔱 Get Elite — $199/mo', url: `${process.env.NEXT_PUBLIC_APP_URL}/upgrade?plan=elite&ref=tg` },
        ]
      ]
    }
  })
})

// ─── Alpha broadcast functions ────────────────────────────────────────────

export async function broadcastAlphaSignal(signal: TokenSignal) {
  if (signal.recommendation !== 'BUY') return

  const text = [
    `⚡ *ALPHA SIGNAL: $${signal.symbol}*`,
    '',
    `Score: *${signal.compositeScore}/100* | ${scoreBar(signal.compositeScore)}`,
    '',
    `✅ Mint: NULL | ✅ Freeze: NULL | ✅ LP Locked`,
    `👛 Smart wallets: ${signal.smartMoney.activeWallets} buying`,
    `💧 Liquidity: $${formatNum(signal.checks.initialLiqUsd)}`,
    `📣 Sentiment: ${signal.sentiment.velocity} mentions/hr`,
    '',
    `\`${signal.mintAddress}\``,
  ].join('\n')

  await bot.sendMessage(CHANNELS.PRO, text, {
    parse_mode: 'Markdown',
    reply_markup: {
      inline_keyboard: [[
        { text: '📈 Trade',       url: `https://jup.ag/swap/SOL-${signal.mintAddress}` },
        { text: '🔍 Dexscreener', url: `https://dexscreener.com/solana/${signal.mintAddress}` },
      ]]
    }
  })
}

export async function broadcastRugAlert(data: { mintAddress: string; symbol?: string; type: string }) {
  const text = [
    `☠️ *RUG DETECTED: $${data.symbol ?? data.mintAddress.slice(0,8)}*`,
    '',
    `Type: \`${data.type.replace(/_/g,' ')}\``,
    `Contract: \`${data.mintAddress}\``,
    '',
    '⚠️ Do NOT buy. Warn your friends.',
  ].join('\n')

  // Free channel — this is the marketing funnel
  if (CHANNELS.FREE) {
    await bot.sendMessage(CHANNELS.FREE, text, { parse_mode: 'Markdown' }).catch(() => {})
  }
}

// ─── Engine WebSocket ─────────────────────────────────────────────────────

export function connectToEngine() {
  const ws = new WebSocket(
    `ws://localhost:${process.env.WS_PORT ?? 3001}?token=${process.env.ENGINE_BOT_TOKEN}`
  )

  ws.on('open', () => {
    ws.send(JSON.stringify({ type: 'SUBSCRIBE', events: ['TOKEN_LAUNCH', 'RUG_ALERT'] }))
  })

  ws.on('message', async (raw) => {
    const event = JSON.parse(raw.toString())
    if (event.type === 'TOKEN_LAUNCH')  await broadcastAlphaSignal(event.data)
    if (event.type === 'RUG_ALERT')     await broadcastRugAlert(event.data)
  })

  ws.on('close', () => setTimeout(connectToEngine, 5000))
}

// ─── Helpers ──────────────────────────────────────────────────────────────

function formatNum(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`
  return n.toFixed(0)
}

function scoreBar(score: number): string {
  const filled = Math.round(score / 10)
  return '█'.repeat(filled) + '░'.repeat(10 - filled)
}
