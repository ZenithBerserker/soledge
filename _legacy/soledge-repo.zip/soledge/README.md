# SolEdge — Solana MEV Intelligence Platform

Real-time MEV-grade signal intelligence for Solana. Token safety scoring, smart money tracking, Meteora DLMM arbitrage detection, Jito bundle analytics, and Discord/Telegram alerting — packaged as a full commercial SaaS.

## Architecture

```
soledge/
├── apps/
│   ├── web/          → Next.js 14 dashboard + API (→ Vercel)
│   ├── engine/       → Signal engine + WebSocket server (→ Railway/bare-metal)
│   └── bot/          → Discord + Telegram bots (→ alongside engine)
├── packages/
│   ├── db/           → Prisma schema + PostgreSQL client
│   └── types/        → Shared TypeScript types
```

## Quick Start

### 1. Environment

```bash
cp .env.example .env
# Fill in all values — see .env.example for full list
```

Required keys:
- `DATABASE_URL` — PostgreSQL (Neon, Supabase, Railway)
- `NEXTAUTH_SECRET` — `openssl rand -base64 32`
- `HELIUS_API_KEY` — [dev.helius.xyz](https://dev.helius.xyz)
- `STRIPE_*` — [dashboard.stripe.com](https://dashboard.stripe.com)
- `GOOGLE_CLIENT_ID/SECRET` — [console.cloud.google.com](https://console.cloud.google.com)

Optional (for full functionality):
- `BIRDEYE_API_KEY` — token market data
- `JITO_AUTH_TOKEN` — authenticated bundle submission
- `DISCORD_BOT_TOKEN` + channel IDs
- `TELEGRAM_BOT_TOKEN` + channel IDs
- `LUNARCRUSH_API_KEY` — social sentiment

### 2. Database

```bash
npm run db:generate   # generate Prisma client
npm run db:push       # push schema to DB
npm run db:seed       # seed starter smart wallets
```

### 3. Run locally

```bash
npm install
npm run dev           # runs all apps via Turborepo
```

- Dashboard: http://localhost:3000
- Engine WS: ws://localhost:3001
- DB Studio: `npm run db:studio`

## Deployment

### Vercel (Web dashboard)

```bash
vercel --prod
```

Set environment variables in Vercel dashboard. The `vercel.json` is pre-configured.

**Stripe webhook**: Add `https://your-domain.vercel.app/api/stripe/webhook` in Stripe dashboard.

### Engine + Bot (Railway / Fly.io / bare-metal)

```bash
# From apps/engine/
npm run build && npm start

# From apps/bot/
npm run build && npm start
```

Set `NEXT_PUBLIC_WS_URL=wss://your-engine-host:3001` in Vercel env vars.

For production MEV, colocate in Frankfurt/New York near Solana validator clusters.

## Signal Pipeline

```
New Raydium/Meteora Pool
       ↓
  Safety Checks (Helius)
  • Mint authority null?
  • Freeze authority null?
  • LP locked + verified?
  • Top-10 concentration < 30%?
  • Bundled launch detected?
       ↓
  Hard rejects → RUG_ALERT (free tier)
       ↓
  Market data + Smart money (Yellowstone/Helius)
  + Sentiment fusion (LunarCrush + Telegram)
  + Deployer reputation
       ↓
  Composite score (0-100)
  Safety×0.40 + SmartMoney×0.25 + Sentiment×0.15 + Liq×0.12 + Deployer×0.08
       ↓
  BUY ≥75 | WATCH ≥50 | SKIP | RUG
       ↓
  Broadcast → WebSocket → Dashboard + Discord + Telegram
```

## Meteora DLMM Arbitrage

The engine continuously monitors Meteora pools for extreme price imbalances:

- **Trigger**: Pool price diverges 50x+ from Jupiter fair price
- **Input cap**: $50 USDC max per opportunity
- **Threshold**: 500x+ projected return after fees + Jito tip
- **Execution**: Full route simulation (USDC → TokenX → TokenY → USDC) before alerting
- **Protection**: Jito bundle with `jitodontfront` to prevent sandwich attacks

## Subscription Tiers

| Feature | Free | Pro ($49/mo) | Elite ($199/mo) |
|---|---|---|---|
| Alerts/day | 5 | 100 | Unlimited |
| Smart wallets | 3 | 12 | Unlimited |
| Rug alerts | ✅ | ✅ | ✅ |
| Alpha signals | ❌ | ✅ | ✅ |
| Meteora ARB | ❌ | ❌ | ✅ |
| Raw API access | ❌ | ❌ | ✅ |
| Discord/TG alerts | ❌ | ✅ | ✅ |

## Key Files

| File | Purpose |
|---|---|
| `apps/engine/src/services/helius.ts` | Raydium launch detection, safety checks, market data |
| `apps/engine/src/services/jito.ts` | Bundle construction, tip auctions, jitodontfront |
| `apps/engine/src/services/smart-money.ts` | Wallet tracking, coordinated exit detection |
| `apps/engine/src/services/scoring.ts` | Composite signal scorer |
| `apps/engine/src/services/meteora.ts` | DLMM arb detection + route simulation |
| `apps/engine/src/services/jito-cron.ts` | Tip snapshots, slot broadcast |
| `apps/engine/src/websocket.ts` | WS server with tier gating |
| `apps/bot/src/discord.ts` | Discord embed alerts |
| `apps/bot/src/telegram.ts` | Telegram channel alerts + commands |
| `packages/db/prisma/schema.prisma` | Full data model |

## Disclaimer

Not financial advice. This is infrastructure tooling. Trading low-cap Solana tokens carries extreme risk of total loss. Use responsibly.
