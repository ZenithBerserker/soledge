import { PrismaClient, WalletCategory } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Seed known smart wallets
  const wallets = [
    { address: '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM', label: 'Insider Alpha #1', category: WalletCategory.INSIDER, trustScore: 95, winRate: 82, totalTrades: 147 },
    { address: 'DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh', label: 'Whale Degen #1', category: WalletCategory.WHALE, trustScore: 88, winRate: 74, totalTrades: 312 },
    { address: 'ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt', label: 'Alpha Caller #1', category: WalletCategory.ALPHA, trustScore: 79, winRate: 68, totalTrades: 89 },
    { address: '3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT', label: 'Copy Trade Bot #1', category: WalletCategory.BOT, trustScore: 71, winRate: 61, totalTrades: 890 },
    { address: 'HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe', label: 'Dev Wallet #1', category: WalletCategory.DEV_WALLET, trustScore: 60, winRate: 55, totalTrades: 44 },
  ]

  for (const w of wallets) {
    await prisma.smartWallet.upsert({
      where: { address: w.address },
      update: {},
      create: { ...w, totalPnlUsd: Math.random() * 200000, isPublic: true },
    })
  }

  console.log(`✅ Seeded ${wallets.length} smart wallets`)
  console.log('🚀 Seed complete!')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
